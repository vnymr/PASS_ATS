# 🔍 Debug Authentication Issues

## Quick Debug Steps

### 1. Check if Content Script is Running

Go to https://happyresumes.com/dashboard and open Console. You should see:
```
🔐 HappyResumes Extension: Dashboard sync script loaded
📍 Running on: https://happyresumes.com/dashboard
```

If you DON'T see this, the content script isn't loading. Fix:
- Reload extension at chrome://extensions
- Refresh the dashboard page

### 2. Check if Clerk is Available

Run this in the Dashboard Console:
```javascript
// Check if Clerk exists
console.log('Clerk available?', typeof window.Clerk !== 'undefined');
console.log('Clerk session?', window.Clerk?.session ? 'Yes' : 'No');
console.log('Clerk user?', window.Clerk?.user?.primaryEmailAddress?.emailAddress);
```

### 3. Manually Extract Token

Run this in the Dashboard Console to get your token:
```javascript
(async () => {
  if (!window.Clerk) {
    console.log('❌ Clerk not found');
    return;
  }

  const session = window.Clerk.session;
  if (!session) {
    console.log('❌ No session - please sign in');
    return;
  }

  const token = await session.getToken();
  console.log('✅ Your token:', token);
  console.log('📋 Token copied to clipboard!');
  navigator.clipboard.writeText(token);
})();
```

### 4. Manually Set Token in Extension

If auto-sync isn't working, manually set the token:

1. Get your token from step 3
2. Go to extension popup
3. Open DevTools for the popup (right-click → Inspect)
4. Run in popup console:
```javascript
chrome.storage.local.set({
  clerk_session_token: 'PASTE_YOUR_TOKEN_HERE',
  clerk_token_updated_at: Date.now()
}, () => {
  console.log('✅ Token manually set');
  location.reload();
});
```

### 5. Check Extension Storage

In the extension popup DevTools, check what's stored:
```javascript
chrome.storage.local.get(null, (data) => {
  console.log('Extension storage:', data);
});
```

### 6. Test Message Passing

In Dashboard Console, test if messages work:
```javascript
// This tests if the content script can send messages
chrome.runtime.sendMessage({
  type: 'TEST',
  message: 'Hello from dashboard'
}, (response) => {
  if (chrome.runtime.lastError) {
    console.error('❌ Message failed:', chrome.runtime.lastError);
  } else {
    console.log('✅ Message sent, response:', response);
  }
});
```

## Common Issues & Fixes

### Issue: "chrome is not defined" in Dashboard Console

**This is normal!** The website doesn't have access to chrome APIs directly.
The content script (dashboard-sync.js) injects into the page and handles this.

### Issue: Token not syncing automatically

1. **Check Console for errors** in both Dashboard and Extension popup
2. **Ensure you're signed in** - Clerk.session must exist
3. **Wait 2-3 seconds** after page load for sync
4. **Look for green notification** in top-right corner

### Issue: "No Clerk token in chrome.storage"

This means the token isn't being saved. Check:
1. Is dashboard-sync.js running? (Check step 1)
2. Can it extract the token? (Check step 3)
3. Are there any errors in background script?

### Check Background Script Logs

1. Go to chrome://extensions
2. Find HappyResumes extension
3. Click "Inspect views: service worker"
4. Check Console for errors

## Working Flow

When everything works correctly, you should see:

**Dashboard Console:**
```
🔐 HappyResumes Extension: Dashboard sync script loaded
📍 Running on: https://happyresumes.com/dashboard
⏰ Starting initial sync in 2 seconds...
🔄 Starting token sync process...
🔍 Checking for Clerk in page context...
✅ Clerk found in page
✅ Token retrieved from Clerk
✅ Token extracted, sending to extension background...
✅ Token synced successfully!
```

**Extension Badge:**
- Green checkmark appears briefly

**Extension Popup:**
- Shows "FREE 0/5" instead of "Sign in"

## Emergency Manual Fix

If nothing else works, here's the nuclear option:

1. Get token from Dashboard (step 3)
2. Open any website
3. Open DevTools Console
4. Run:
```javascript
// Create a temporary extension page to set storage
const url = `chrome-extension://YOUR_EXTENSION_ID/popup/popup.html`;
window.open(url);
```
5. In that new tab's console, set the token manually (step 4)

## Still Not Working?

1. **Check Chrome version** - Must be 100+
2. **Try Incognito mode** - Allow extension in incognito
3. **Disable other extensions** temporarily
4. **Clear all site data** for happyresumes.com and try again
5. **Reinstall extension** completely

The issue is usually one of:
- Content script not loading on dashboard
- Clerk not available when script runs
- Message passing blocked
- Storage permission issues