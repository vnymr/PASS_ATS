// Extension Storage Debug Script
// Run this in the extension's background script console or popup console

console.log('🔍 Checking extension storage...');

// Check chrome.storage.local for the token
chrome.storage.local.get(['clerk_session_token', 'clerk_token_updated_at', 'user_email'], (result) => {
  console.log('\n📦 Chrome Storage Contents:');

  if (result.clerk_session_token) {
    console.log('✅ Token found in storage!');
    console.log('  - Token (first 50 chars):', result.clerk_session_token.substring(0, 50) + '...');
    console.log('  - Token length:', result.clerk_session_token.length);
    console.log('  - User email:', result.user_email || 'Not stored');

    if (result.clerk_token_updated_at) {
      const updatedAt = new Date(result.clerk_token_updated_at);
      const ageMinutes = Math.floor((Date.now() - result.clerk_token_updated_at) / 1000 / 60);
      console.log('  - Last updated:', updatedAt.toLocaleString());
      console.log('  - Age:', ageMinutes, 'minutes');
    }
  } else {
    console.log('❌ No token found in storage');
  }

  // Also check for any jobs in storage
  console.log('\n📋 Checking for stored jobs...');
  chrome.storage.local.get(['jobs'], (jobResult) => {
    if (jobResult.jobs && jobResult.jobs.length > 0) {
      console.log('✅ Found', jobResult.jobs.length, 'stored jobs');
      jobResult.jobs.slice(0, 3).forEach((job, index) => {
        console.log(`  ${index + 1}. ${job.title || 'Unknown'} at ${job.company || 'Unknown'}`);
      });
    } else {
      console.log('📭 No jobs stored');
    }
  });
});

// Clear storage if needed
console.log('\n🗑️ To clear storage, run:');
console.log('chrome.storage.local.clear(() => console.log("Storage cleared!"));');

// Force refresh token
console.log('\n🔄 To manually request token refresh from dashboard, run:');
console.log(`chrome.tabs.query({url: '*://happyresumes.com/*'}, (tabs) => {
  if (tabs.length > 0) {
    chrome.tabs.sendMessage(tabs[0].id, {type: 'REQUEST_TOKEN_REFRESH'}, (response) => {
      console.log('Token refresh response:', response);
    });
  } else {
    console.log('No HappyResumes tabs open');
  }
});`);