# Extension Icons

Place your extension icons here:

- `icon-16.png` - 16x16 pixels (toolbar icon)
- `icon-48.png` - 48x48 pixels (extension management)
- `icon-128.png` - 128x128 pixels (Chrome Web Store)

## Design Guidelines

- Use a simple, recognizable design
- Orange theme (#FF6B35) to match branding
- Include a document/resume icon
- Make it work at small sizes (16x16 must be clear)

## Quick Generation

You can generate placeholder icons using an online tool like:
- https://www.iconfinder.com
- https://www.flaticon.com
- Or create custom ones in Figma/Canva

For now, you can use a simple emoji or SVG as a placeholder.
