# 🧪 Complete Extension Testing Checklist

## Before You Start

### **Prerequisites:**
- [ ] Chrome browser installed
- [ ] Extension folder at: `/Users/vinaymuthareddy/RESUME_GENERATOR/extension`
- [ ] HappyResumes account (for testing authentication)
- [ ] LinkedIn account (for testing job scraping)

---

## 🎯 Test Plan Overview

We'll test:
1. ✅ Extension loads without errors
2. ✅ Icons display correctly
3. ✅ Authentication works
4. ✅ Job detection works on LinkedIn
5. ✅ Job extraction works (gets title, company, description)
6. ✅ Resume generation starts
7. ✅ Full end-to-end flow

---

## Step 1: Load Extension in Chrome

### **Actions:**
```bash
# 1. Open Chrome
# 2. Go to: chrome://extensions/
# 3. Toggle ON "Developer mode" (top right)
# 4. Click "Load unpacked"
# 5. Navigate to: /Users/vinaymuthareddy/RESUME_GENERATOR/extension
# 6. Click "Select"
```

### **Expected Result:**
- ✅ Extension appears in list
- ✅ No red error messages
- ✅ Icon appears in Chrome toolbar (check if it's visible, not a broken image)
- ✅ Version shows: 1.2.2

### **If It Fails:**
❌ **Red error message appears**
- Check the error text
- Look for file not found errors
- Common issue: manifest.json syntax error

❌ **Icon is broken/blank**
- Icons are still too small or corrupted
- Need to replace with proper icons (see ICON_QUICK_FIX.md)

---

## Step 2: Check Extension Background Console

### **Actions:**
```bash
# In chrome://extensions/
# Find "HappyResumes - AI Resume Builder"
# Click "Inspect views: service worker"
# A DevTools window will open
```

### **Expected Console Output:**
```
🚀 HappyResumes service worker loaded
```

### **Expected: NO Errors**
- ❌ Should NOT see: "Uncaught Error"
- ❌ Should NOT see: "Failed to load"
- ❌ Should NOT see: "SyntaxError"

### **If You See Errors:**
- Copy the full error message
- Share it with me for debugging

---

## Step 3: Test Extension Popup (Without Auth)

### **Actions:**
```bash
# 1. Click the HappyResumes icon in Chrome toolbar
# 2. Popup window should open
```

### **Expected Result:**
```
✅ Popup opens
✅ Shows: "HappyResumes" header
✅ Shows: "Sign in to generate resumes"
✅ Shows: Blue "Sign In" button
✅ NO console errors
```

### **To Check Console:**
```bash
# Right-click inside popup
# Click "Inspect"
# Go to Console tab
```

### **Expected Console (Popup):**
```
🎯 HappyResumes popup loaded
🔐 Checking for stored token...
❌ No token found in storage
```

### **If It Fails:**
❌ **Popup doesn't open**
- Check service worker console for errors
- Check popup.html exists
- Check popup.js has no syntax errors

❌ **Popup is blank**
- popup.html not loading
- Check manifest.json → action.default_popup path

❌ **Console shows errors**
- Copy error message
- Share with me

---

## Step 4: Test Authentication Flow

### **Actions:**
```bash
# 1. In extension popup, click "Sign In" button
# 2. New tab opens to: https://happyresumes.com/dashboard
# 3. Sign in with your HappyResumes account
# 4. After signing in, STAY on dashboard page
# 5. Wait 3-5 seconds
# 6. Look for notification in top-right corner
```

### **Expected Result:**
```
✅ Opens happyresumes.com/dashboard in new tab
✅ After sign in, green notification appears:
   "✅ Authentication synced to extension!"
✅ Extension badge shows green checkmark (briefly)
```

### **To Verify Token Stored:**
```bash
# Open popup again
# Right-click → Inspect
# Console tab, run:
chrome.storage.local.get(['clerk_session_token'], (data) => {
  console.log('Token exists?', !!data.clerk_session_token);
  console.log('Token length:', data.clerk_session_token?.length);
});

# Expected output:
# Token exists? true
# Token length: 200-500 (varies)
```

### **If It Fails:**
❌ **No notification appears**
- Check dashboard page console (F12)
- Look for: "Dashboard sync script STARTED"
- If missing, content script not loading

❌ **Token not stored**
- Check service worker console
- Look for: "Token from dashboard saved to storage"
- If missing, message passing failed

---

## Step 5: Test Job Detection (LinkedIn)

### **Actions:**
```bash
# 1. Go to: https://www.linkedin.com/jobs/search/
# 2. Click ANY job in the list to open it
# 3. Wait for job details to load (right side panel)
# 4. Click extension icon to open popup
```

### **Expected Result (Main Test):**
```
✅ Popup shows:
   - Job title (e.g., "Senior Software Engineer")
   - Company name (e.g., "Google")
   - Green "⚡ Generate Resume" button

✅ NOT showing:
   - "📋 Open a job posting to generate resume"
```

### **Check Popup Console:**
```bash
# Right-click popup → Inspect
# Console should show:

🔍 Checking page: https://www.linkedin.com/jobs/view/...
🌐 Is job site? true
📝 Injecting scraper scripts...
✅ All scripts injected and initialized
🔍 Attempting to extract job data...
📄 Checking for jobScraper... function
✅ jobScraper found, extracting...
📄 Found LinkedIn content using selector: .jobs-description__content
✅ Found job title via selector: .jobs-unified-top-card__job-title
✅ Found company via selector: .jobs-unified-top-card__company-name
📦 Extracted data: {
  hasMetadata: true,
  descriptionLength: 2500-5000,
  title: "Senior Software Engineer",
  company: "Google"
}
✅ Job detected: Senior Software Engineer @ Google
```

### **If It Fails:**

❌ **Shows "📋 Open a job posting..." instead of job details**

**Debug in popup console:**
```javascript
// Run this in popup console:
chrome.tabs.query({ active: true }, async ([tab]) => {
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => ({
      hasJobScraper: typeof window.jobScraper,
      hasCONFIG: typeof window.CONFIG,
      url: window.location.href
    })
  });
  console.log('Page state:', results[0].result);
});
```

**Expected:**
```javascript
{
  hasJobScraper: "function",
  hasCONFIG: "object",
  url: "https://www.linkedin.com/jobs/view/..."
}
```

**If jobScraper is undefined:**
- Scripts not injecting properly
- Try refreshing LinkedIn page
- Try reloading extension

❌ **Description length is 0 or very small (<500)**
- LinkedIn changed their HTML structure
- Selectors not finding content
- Try clicking "Show more" on job description
- Share the LinkedIn URL with me

---

## Step 6: Test Job Extraction Manually

### **Actions:**
```bash
# 1. On a LinkedIn job page
# 2. Open browser console (F12)
# 3. NOT popup console - the MAIN page console
# 4. Run this:
```

```javascript
// Test extraction directly
if (window.jobScraper) {
  const data = window.jobScraper.extractJobContent();
  console.log('Extraction test:', {
    title: data.metadata?.title,
    company: data.metadata?.company,
    descriptionLength: data.fullDescription?.length,
    firstLine: data.fullDescription?.substring(0, 100)
  });
} else {
  console.error('jobScraper not found - scripts not loaded');
}
```

### **Expected Output:**
```javascript
{
  title: "Senior Software Engineer",
  company: "Google",
  descriptionLength: 3421,
  firstLine: "We are looking for a talented Senior Software Engineer to join our team in Mountain View..."
}
```

### **If It Fails:**
❌ **jobScraper not found**
- Extension scripts not loading on page
- Check: extension has permission for linkedin.com
- Try: Refresh page, reload extension

❌ **descriptionLength: 0 or undefined**
- Selectors not finding content
- Run this to debug:
```javascript
// Check what selectors find
const selectors = [
  '.jobs-description__content',
  '.jobs-box__html-content',
  '[class*="job-description"]'
];

selectors.forEach(sel => {
  const el = document.querySelector(sel);
  console.log(sel, '→', el ? `Found (${el.innerText.length} chars)` : 'Not found');
});
```

---

## Step 7: Test Resume Generation

### **Actions:**
```bash
# 1. With job detected in popup
# 2. Click "⚡ Generate Resume" button
# 3. Watch for loading state
```

### **Expected Result:**
```
✅ Button changes to: "🔄 Starting..."
✅ After 1-2 seconds: "✓ Processing in background"
✅ "Recent Jobs" section expands automatically
✅ New job appears with:
   - ⏳ icon
   - "PROCESSING" status
   - Progress bar (0% → 100%)
```

### **Expected Console (Service Worker):**
```bash
# In chrome://extensions/ → service worker console:

🚀 Starting background job processing: cmgh...
📊 Status update: { status: 'PROCESSING', progress: 15 }
📊 Status update: { status: 'PROCESSING', progress: 45 }
📊 Status update: { status: 'PROCESSING', progress: 75 }
✅ Job completed successfully
```

### **Expected Time:**
- Generation: 30-60 seconds
- Poll updates: Every 2 seconds

### **If It Fails:**

❌ **Button shows error immediately**
- Check popup console for error
- Common: "UNAUTHORIZED" → token expired, sign in again
- Common: "RATE_LIMITED" → wait a moment

❌ **Job starts but fails**
- Check service worker console
- Look for API error response
- Check if backend is running

❌ **Job stuck at 0% forever**
- Backend may be down
- Check: https://api.happyresumes.com/health
- Or backend job processing failed

---

## Step 8: Test Keyboard Shortcut

### **Actions:**
```bash
# 1. Go to a LinkedIn job page
# 2. Press: Alt + Shift + R (Windows/Linux)
#    OR:     Cmd + Shift + Y (Mac)
# 3. Watch for toast notification
```

### **Expected Result:**
```
✅ Toast appears in top-right: "⚡ Scanning for job..."
✅ After 2 seconds: "Generating tailored resume..."
✅ Job appears in extension popup (Recent Jobs section)
✅ NO popup window opens (silent mode)
```

### **If It Fails:**
❌ **Nothing happens**
- Shortcut may be conflicting
- Go to: chrome://extensions/shortcuts
- Check if "Generate resume" is assigned
- Try changing to different key combo

❌ **Error toast appears**
- Check page console for error details
- May be auth issue or extraction issue

---

## Step 9: Test Download

### **Actions:**
```bash
# 1. Wait for job to complete (status: COMPLETED)
# 2. In popup, job should show:
#    - ✓ icon
#    - "COMPLETED" status
#    - Download button (↓)
# 3. Click download button
```

### **Expected Result:**
```
✅ PDF downloads to ~/Downloads/
✅ Filename: Resume_[jobId].pdf or similar
✅ File size: 50-200 KB
✅ PDF opens and shows tailored resume
```

### **If It Fails:**
❌ **No download starts**
- Check service worker console
- Look for: "Download failed"
- May be permission issue

❌ **PDF is corrupted**
- Backend generation failed
- Try downloading from dashboard instead

---

## Step 10: Test Full End-to-End Flow

### **Complete User Journey:**
```bash
1. Sign in to extension (dashboard)
2. Go to LinkedIn job search
3. Click a job posting
4. Open extension popup
5. Click "Generate Resume"
6. Wait for completion (~45 seconds)
7. Download PDF
8. Verify PDF looks good
```

### **Success Criteria:**
- [ ] All steps complete without errors
- [ ] Resume PDF is tailored to job
- [ ] Job title/company correct in resume
- [ ] PDF is exactly 1 page
- [ ] ATS-optimized formatting

---

## 🐛 Common Issues & Fixes

### **Issue 1: "jobScraper not found"**
**Fix:**
```bash
# Reload extension:
# chrome://extensions/ → Click reload button
# Refresh LinkedIn page
# Try again
```

### **Issue 2: "No token found"**
**Fix:**
```bash
# Sign in again:
# Open popup → Sign In
# Stay on dashboard for 5 seconds
# Check for green notification
```

### **Issue 3: "Description length: 0"**
**Fix:**
```bash
# On LinkedIn job page:
# Click "Show more" to expand description
# Wait 2 seconds
# Try extraction again
```

### **Issue 4: "Generation failed"**
**Fix:**
```bash
# Check backend is running:
curl https://api.happyresumes.com/health

# If down, start backend:
cd /Users/vinaymuthareddy/RESUME_GENERATOR/server
npm start
```

---

## 📊 Test Results Template

Copy this and fill in your results:

```
## Extension Test Results

Date: [Today's date]
Extension Version: 1.2.2
Chrome Version: [Check in chrome://version]

### 1. Extension Loads
- [ ] ✅ Loads without errors
- [ ] ✅ Icons display correctly
- [ ] ❌ [Issue description]

### 2. Authentication
- [ ] ✅ Sign in works
- [ ] ✅ Token stored
- [ ] ❌ [Issue description]

### 3. Job Detection (LinkedIn)
- [ ] ✅ Detects job page
- [ ] ✅ Shows job title/company
- [ ] ✅ Extract button appears
- [ ] ❌ [Issue description]

Test URL: [LinkedIn job URL]
Job Title Found: [Title]
Company Found: [Company]
Description Length: [Number] characters

### 4. Job Extraction
- [ ] ✅ Extracts full description
- [ ] ✅ Metadata correct
- [ ] ❌ [Issue description]

### 5. Resume Generation
- [ ] ✅ Starts successfully
- [ ] ✅ Progress updates
- [ ] ✅ Completes
- [ ] ❌ [Issue description]

Time taken: [Seconds]

### 6. Download
- [ ] ✅ PDF downloads
- [ ] ✅ PDF opens correctly
- [ ] ✅ Content looks good
- [ ] ❌ [Issue description]

### 7. Keyboard Shortcut
- [ ] ✅ Works
- [ ] ❌ [Issue description]

### Issues Found:
1. [Issue 1 description]
2. [Issue 2 description]

### Overall Result:
- [ ] ✅ All tests pass
- [ ] ⚠️  Some issues (list above)
- [ ] ❌ Major blocker (describe)
```

---

## 🚀 After Testing

### **If All Tests Pass:**
1. ✅ Extension is ready
2. Replace icons (ICON_QUICK_FIX.md)
3. Create privacy policy
4. Resubmit to Chrome Web Store

### **If Tests Fail:**
1. Fill in test results template above
2. Share with me
3. Include:
   - Console logs (popup + service worker)
   - Screenshots of errors
   - Specific LinkedIn URL that failed
4. I'll help debug

---

## 📝 Quick Debug Commands

**Check if scripts loaded:**
```javascript
// In page console (LinkedIn):
console.log('CONFIG:', typeof window.CONFIG);
console.log('apiClient:', typeof window.apiClient);
console.log('jobScraper:', typeof window.jobScraper);
```

**Check token:**
```javascript
// In popup console:
chrome.storage.local.get(['clerk_session_token'], console.log);
```

**Force extraction test:**
```javascript
// In page console (LinkedIn):
window.jobScraper?.extractJobContent();
```

**Check active jobs:**
```javascript
// In popup console:
chrome.runtime.sendMessage({ action: 'GET_ACTIVE_JOBS' }, console.log);
```

---

Ready to test? Start with **Step 1** and work through each step. Let me know what you find! 🎯
