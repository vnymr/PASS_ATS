# Extension Testing Checklist

## Pre-Installation Setup

1. **Check Chrome Version**
   - Ensure Chrome is updated to latest version
   - Go to chrome://version to verify

2. **Clean Previous Installation**
   - Go to chrome://extensions
   - Remove any previous version of Quick Resume AI
   - Clear browser cache (Cmd+Shift+Delete on Mac, Ctrl+Shift+Delete on Windows)

## Installation Steps

1. **Load Extension**
   - Open chrome://extensions
   - Enable "Developer mode" (top right)
   - Click "Load unpacked"
   - Select the `/extension` folder
   - Verify extension appears with name "Quick Resume AI"

2. **Check Permissions**
   - Click on "Details" for the extension
   - Verify permissions show:
     - ✅ storage
     - ✅ downloads
     - ✅ notifications
     - ✅ alarms
     - ✅ activeTab
     - ✅ scripting
   - Should NOT show "Read and change all your data on all websites"

## Functionality Testing

### Test 1: Keyboard Shortcut Activation
- **Windows/Linux**: Press `Alt + R`
- **Mac**: Press `⌘ + Shift + G`

#### 1.1 Test on Job Site (LinkedIn)
1. Go to: https://www.linkedin.com/jobs/view/[any-job-id]
2. Press the keyboard shortcut
3. **Expected**:
   - ✅ "⚡ Scanning for job..." notification appears
   - ✅ Job extraction overlay appears
   - ✅ Job preview shows with title, company, description

#### 1.2 Test on Job Site (Indeed)
1. Go to: https://www.indeed.com/viewjob?jk=[any-job-id]
2. Press the keyboard shortcut
3. **Expected**:
   - ✅ Same as LinkedIn test

#### 1.3 Test on Non-Job Site
1. Go to: https://www.google.com
2. Press the keyboard shortcut
3. **Expected**:
   - ✅ "⚡ Scanning for job..." notification appears
   - ✅ Manual input form appears
   - ✅ Can paste job description manually

#### 1.4 Test on Chrome Page
1. Go to: chrome://extensions
2. Press the keyboard shortcut
3. **Expected**:
   - ✅ Notification: "Extension cannot run on this page"

### Test 2: Popup Functionality

1. Click extension icon in toolbar
2. **Expected**:
   - ✅ Popup opens
   - ✅ Shows keyboard shortcut hint
   - ✅ Shows auth status or main view

### Test 3: Authentication

1. If not signed in:
   - ✅ Popup shows "Sign in to generate resumes"
   - ✅ Sign In button opens happyresumes.com

2. Sign in at happyresumes.com
3. Return to extension popup
4. **Expected**:
   - ✅ Shows user tier (FREE/PRO)
   - ✅ Shows usage count

### Test 4: Resume Generation (Requires Auth)

1. Sign in first
2. Go to any LinkedIn job
3. Press keyboard shortcut
4. Click "Generate Resume" in preview
5. **Expected**:
   - ✅ Progress bar appears
   - ✅ Status updates show
   - ✅ PDF auto-downloads when complete
   - ✅ Success notification appears

### Test 5: Manual Input

1. Press shortcut on any non-job page
2. Paste this test job description:
```
Software Engineer
Tech Company Inc.
San Francisco, CA

We are looking for a skilled Software Engineer with experience in:
- JavaScript/TypeScript
- React
- Node.js
- Cloud technologies

Responsibilities:
- Develop web applications
- Write clean code
- Collaborate with team

Requirements:
- 3+ years experience
- BS in Computer Science
- Strong problem solving skills
```
3. Click "Generate Resume"
4. **Expected**:
   - ✅ Extracts job data correctly
   - ✅ Shows preview
   - ✅ Can generate resume

## Error Testing

### Test 6: Network Error
1. Turn off internet
2. Press shortcut on job page
3. **Expected**:
   - ✅ Error message appears
   - ✅ Extension doesn't crash

### Test 7: Multiple Activations
1. Press shortcut multiple times quickly
2. **Expected**:
   - ✅ Only one overlay appears
   - ✅ No duplicate processing

## Performance Testing

### Test 8: Memory Usage
1. Open chrome://extensions
2. Click "Inspect views: service worker"
3. Go to Memory tab
4. **Expected**:
   - ✅ Memory usage < 50MB when idle
   - ✅ No memory leaks after multiple uses

### Test 9: No Background Activity
1. Browse normally without pressing shortcut
2. Check DevTools Network tab
3. **Expected**:
   - ✅ No extension requests
   - ✅ No console errors
   - ✅ No performance impact

## Issues to Check

### Known Issues to Verify Fixed:
- [x] Extension no longer runs on all websites
- [x] No localhost references in production
- [x] Keyboard shortcut doesn't conflict with refresh
- [x] Scripts only inject when activated
- [x] No auto-detection running constantly

### Console Checks:
1. Open DevTools Console
2. Filter by extension (chrome-extension://)
3. Look for:
   - ❌ Red errors (should be none)
   - ⚠️ Warnings (minimal)
   - 📝 Debug logs (will be removed for production)

## Final Verification

### Security Check:
- [ ] Extension only activates on demand
- [ ] No access to all websites
- [ ] User data stays private
- [ ] No background tracking

### User Experience:
- [ ] Clear visual feedback
- [ ] Fast response time (<1s)
- [ ] Clean UI/overlay
- [ ] Keyboard shortcut works reliably

## Report Issues

If you find any issues:
1. Note the exact steps to reproduce
2. Check console for errors
3. Take screenshot if visual issue
4. Report with:
   - Chrome version
   - OS (Windows/Mac/Linux)
   - Job site URL (if applicable)
   - Error message (if any)

---

## Summary

✅ **Ready for Testing** if all core functions work:
- Keyboard shortcut activates extension
- Job detection works on major sites
- Manual input fallback works
- No crashes or major errors
- Performance is good

⚠️ **Known Limitations**:
- 66 debug console.log statements (will be removed for production)
- Placeholder icons (will be replaced)
- No automated tests yet

The extension is functionally complete and ready for user testing!