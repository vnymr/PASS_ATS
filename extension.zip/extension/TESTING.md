# Testing Quick Resume AI Extension

## Pre-Testing Checklist

- [ ] Backend server is running (`npm start` in `/server`)
- [ ] Extension is loaded in Chrome (`chrome://extensions/`)
- [ ] You have test credentials or can register

## Test Cases

### 1. Installation & Setup

**Steps:**
1. Load extension in Chrome
2. Click extension icon
3. Register new account or login
4. Verify you see the main screen with quota display

**Expected:**
- Extension loads without errors
- Login/register works
- Main screen shows "0 / 50 resumes this month"

---

### 2. Job Detection - Known Sites

**Sites to test:**
- LinkedIn: https://www.linkedin.com/jobs/
- Indeed: https://www.indeed.com/
- Glassdoor: https://www.glassdoor.com/Job/

**Steps:**
1. Navigate to a job posting on each site
2. Wait 2-3 seconds
3. Look for orange floating button in bottom-right

**Expected:**
- Floating button appears automatically
- Button has pulse animation
- Console shows "✅ Job page detected"

---

### 3. Job Extraction & Preview

**Steps:**
1. On a job page, click floating button
2. Wait for extraction (2-5 seconds)
3. Review extracted details in overlay

**Expected:**
- "Analyzing job posting..." message appears
- Overlay shows extracted:
  - Job title
  - Company name
  - Location
  - Skills (if present)
  - Key requirements (if present)
- Can close overlay with X button
- Can click "Cancel" to close

---

### 4. Resume Generation

**Steps:**
1. After extraction, click "Generate Resume"
2. Watch progress indicator
3. Wait for completion (15-30 seconds)

**Expected:**
- Shows "Generating..." with progress message
- Progress updates as status changes
- Shows "Resume Ready!" on completion
- Download button appears

---

### 5. Download Resume

**Steps:**
1. After generation completes, click "Download PDF"
2. Check Chrome downloads

**Expected:**
- PDF download starts automatically
- File named `resume-{jobId}.pdf`
- PDF opens correctly
- Resume content is tailored to the job

---

### 6. Manual Input Fallback

**Steps:**
1. Visit a non-job page (e.g., Google.com)
2. Click extension icon
3. Paste a job description in textarea
4. Click "Generate Resume"

**Expected:**
- Can paste text successfully
- Generate button activates
- Generation starts
- Can track in popup history

---

### 7. Keyboard Shortcut

**Steps:**
1. On a job page, press `Alt+R` (Windows/Linux) or `⌥+R` (Mac)
2. Watch for overlay

**Expected:**
- Overlay appears immediately
- Same flow as clicking button
- Shows "This doesn't appear to be a job page" if not on job site

---

### 8. Error Handling - Network Offline

**Steps:**
1. Turn off internet connection
2. Try to generate a resume
3. Turn internet back on

**Expected:**
- Shows "Network error" message
- Doesn't crash
- Retries when connection restored

---

### 9. Error Handling - Extraction Fails

**Steps:**
1. On a very simple page with minimal content
2. Click floating button

**Expected:**
- Shows manual input fallback
- Can paste job description manually
- Generation still works

---

### 10. Error Handling - Rate Limiting

**Steps:**
1. Generate 6 resumes in quick succession
2. Try to generate 7th

**Expected:**
- Shows rate limit error
- Tells user to wait
- Doesn't crash extension

---

### 11. Quota Display

**Steps:**
1. Generate several resumes
2. Click extension icon
3. Check quota card

**Expected:**
- Quota increments with each generation
- Progress bar updates
- Shows "X / 50 resumes this month"

---

### 12. Resume History

**Steps:**
1. After generating 2-3 resumes
2. Click extension icon
3. Check "Recent Resumes" section

**Expected:**
- Shows last 5 resumes
- Displays job title, company, date
- Can click download button to re-download

---

### 13. Settings

**Steps:**
1. Click extension icon
2. Click "⚙️ Settings"
3. Change API URL
4. Click Save

**Expected:**
- Settings page loads
- Can edit API URL
- Save persists across sessions
- Shows version number

---

### 14. Logout & Re-login

**Steps:**
1. Click logout
2. Verify logged out
3. Login again

**Expected:**
- Returns to login screen
- Token cleared from storage
- Can login successfully
- State restored

---

### 15. Dark Mode

**Steps:**
1. Enable dark mode in your OS
2. Open extension popup
3. Click floating button on a job page

**Expected:**
- UI respects dark mode
- All text remains readable
- Orange accent color still visible

---

### 16. Heuristic Detection (Unknown Sites)

**Steps:**
1. Find a job posting on a non-major site (e.g., company careers page)
2. Navigate to it
3. Wait for detection

**Expected:**
- Floating button appears if page has:
  - 3+ job keywords
  - Apply button
  - Job-like content
- Console shows confidence score

---

### 17. Multi-Tab Usage

**Steps:**
1. Open 3 job postings in different tabs
2. Click floating button in each
3. Start generation in each

**Expected:**
- Each tab works independently
- No conflicts between tabs
- All 3 resumes generate successfully

---

### 18. Extension Update/Reload

**Steps:**
1. While on a job page, reload extension
2. Refresh page
3. Try generation again

**Expected:**
- Works after reload
- No "Extension context invalidated" errors
- State persists

---

## Performance Tests

### Load Time
- Extension should load in < 500ms
- Floating button appears in < 1s after page load

### Memory Usage
- Check: `chrome://extensions/` → Details → Inspect service worker
- Should use < 30MB RAM

### Network Efficiency
- Extraction: 1 API call (cached for 24hrs)
- Generation: 1 initial + ~10 polling requests
- Total data: < 1MB per job

---

## Browser Compatibility

Test on:
- [ ] Chrome (latest)
- [ ] Chrome (v100+)
- [ ] Edge (Chromium-based)
- [ ] Brave

**Note:** Firefox/Safari use different extension APIs (WebExtensions). This is Chrome only for now.

---

## Known Issues / Limitations

1. **Icons are placeholders** - Need proper icon design
2. **No Redux/state management** - Fine for MVP, may need refactor for complex features
3. **In-memory cache** - Should use Redis in production
4. **No analytics** - Can't track usage metrics yet
5. **No A/B testing** - Can't optimize UX with data

---

## Debugging Tips

### Check Extension Console
```
chrome://extensions/ → Quick Resume AI → Inspect service worker
```

### Check Content Script Console
```
F12 on any job page → Console tab
Look for: "🎯 Job page detected"
```

### Check API Logs
```
Server terminal shows all API requests and responses
```

### Clear Extension Storage
```javascript
chrome.storage.local.clear()
```

### Force Cache Clear
```javascript
// In service worker console
chrome.alarms.create('cleanupCache', { when: Date.now() })
```

---

## Reporting Bugs

When reporting issues, include:
1. Chrome version
2. Extension version
3. Job site URL (if applicable)
4. Console errors (screenshot)
5. Steps to reproduce

---

## Success Criteria

Extension is ready when:
- ✅ All 18 test cases pass
- ✅ No console errors during normal usage
- ✅ Works on 5+ different job sites
- ✅ Generation completes in < 30s avg
- ✅ Error handling graceful (no crashes)
- ✅ Memory usage < 30MB
- ✅ UI responsive and intuitive

---

Happy testing! 🚀
