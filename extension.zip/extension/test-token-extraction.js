// Manual Token Extraction Test Script
// Copy and paste this into the browser console while on happyresumes.com

console.log('🧪 Testing Clerk token extraction...');

// Test 1: Check if Clerk exists
console.log('\n📋 Test 1: Checking for Clerk object...');
if (typeof window.Clerk !== 'undefined') {
  console.log('✅ window.Clerk exists');
  console.log('Clerk object:', window.Clerk);
} else {
  console.log('❌ window.Clerk not found');
  console.log('Checking alternative locations...');

  if (window.__clerk) {
    console.log('✅ Found window.__clerk');
  } else if (window.__CLERK__) {
    console.log('✅ Found window.__CLERK__');
  } else {
    console.log('❌ No Clerk object found anywhere');
    console.log('Keys containing "clerk":', Object.keys(window).filter(k => k.toLowerCase().includes('clerk')));
  }
}

// Test 2: Check session
console.log('\n📋 Test 2: Checking for session...');
if (window.Clerk?.session) {
  console.log('✅ Session exists');
  console.log('Session ID:', window.Clerk.session.id);
} else {
  console.log('❌ No session found');
}

// Test 3: Check user
console.log('\n📋 Test 3: Checking for user...');
if (window.Clerk?.user) {
  console.log('✅ User exists');
  console.log('User ID:', window.Clerk.user.id);
  console.log('Email:', window.Clerk.user.primaryEmailAddress?.emailAddress);
} else {
  console.log('❌ No user found');
}

// Test 4: Try to get token
console.log('\n📋 Test 4: Attempting to get token...');
if (window.Clerk?.session) {
  window.Clerk.session.getToken()
    .then(token => {
      console.log('✅ Token retrieved successfully!');
      console.log('Token (first 50 chars):', token ? token.substring(0, 50) + '...' : 'null');
      console.log('Token length:', token ? token.length : 0);

      // Test 5: Test sending to extension
      console.log('\n📋 Test 5: Testing extension communication...');
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.sendMessage({
          type: 'CLERK_TOKEN_UPDATE',
          token: token,
          email: window.Clerk.user?.primaryEmailAddress?.emailAddress,
          source: 'manual-test',
          timestamp: new Date().toISOString()
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Failed to send to extension:', chrome.runtime.lastError);
          } else {
            console.log('✅ Token sent to extension successfully!', response);
          }
        });
      } else {
        console.log('⚠️ Chrome extension API not available (are you on happyresumes.com?)');
      }
    })
    .catch(error => {
      console.error('❌ Failed to get token:', error);
    });
} else {
  console.log('⚠️ Cannot get token - no session available');
}

// Test 6: Check cookies
console.log('\n📋 Test 6: Checking cookies...');
const cookies = document.cookie.split(';').map(c => c.trim());
const clerkCookies = cookies.filter(c => c.includes('__session') || c.includes('__client') || c.includes('clerk'));
if (clerkCookies.length > 0) {
  console.log('✅ Found Clerk-related cookies:', clerkCookies.length);
  clerkCookies.forEach(c => {
    const [name] = c.split('=');
    console.log('  -', name);
  });
} else {
  console.log('❌ No Clerk cookies found');
}

console.log('\n🏁 Token extraction test complete!');
console.log('If all tests passed, the extension should have received the token.');
console.log('Check the extension popup to verify authentication status.');