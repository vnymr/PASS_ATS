// Job extraction strategies for different sites
const extractors = {
  // LinkedIn
  'linkedin.com': () => {
    const title = document.querySelector('.job-details-jobs-unified-top-card__job-title, .jobs-unified-top-card__job-title, h1.t-24')?.textContent?.trim();
    const company = document.querySelector('.job-details-jobs-unified-top-card__company-name, .jobs-unified-top-card__company-name, .jobs-unified-top-card__subtitle-primary-grouping a')?.textContent?.trim();
    const location = document.querySelector('.job-details-jobs-unified-top-card__bullet, .jobs-unified-top-card__bullet, .jobs-unified-top-card__subtitle-secondary-grouping span')?.textContent?.trim();
    const description = document.querySelector('.jobs-description__content, .jobs-box__html-content, #job-details')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Indeed
  'indeed.com': () => {
    const title = document.querySelector('.jobsearch-JobInfoHeader-title, h1[data-testid="jobsearch-JobInfoHeader-title"]')?.textContent?.trim();
    const company = document.querySelector('.jobsearch-InlineCompanyRating-companyHeader a, [data-testid="inlineHeader-companyName"]')?.textContent?.trim();
    const location = document.querySelector('.jobsearch-JobInfoHeader-subtitle > div:last-child, [data-testid="job-location"]')?.textContent?.trim();
    const description = document.querySelector('#jobDescriptionText, .jobsearch-jobDescriptionText')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Glassdoor
  'glassdoor.com': () => {
    const title = document.querySelector('[data-test="job-title"], .css-1vg6q84')?.textContent?.trim();
    const company = document.querySelector('[data-test="employer-name"], .css-87uc0g')?.textContent?.trim();
    const location = document.querySelector('[data-test="location"], .css-56kyx5')?.textContent?.trim();
    const description = document.querySelector('[data-test="job-description"], .jobDescriptionContent')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Lever
  'lever.co': () => {
    const title = document.querySelector('.posting-headline h2, .posting-title')?.textContent?.trim();
    const company = document.querySelector('.posting-headline .company-name, .main-header-logo img')?.alt || document.querySelector('.posting-categories .location')?.textContent?.trim()?.split(' - ')[0];
    const location = document.querySelector('.posting-categories .location, .sort-by-time')?.textContent?.trim();
    const description = document.querySelector('.posting-description, [data-qa="job-description"]')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Greenhouse
  'greenhouse.io': () => {
    const title = document.querySelector('.app-title, h1.heading')?.textContent?.trim();
    const company = document.querySelector('.company-name, .logo img')?.alt || '';
    const location = document.querySelector('.location, .body--metadata')?.textContent?.trim();
    const description = document.querySelector('#content, .job-post-content, .content')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Workday
  'workday.com': () => {
    const title = document.querySelector('[data-automation-id="jobPostingHeader"], h2.css-1gxwj5g')?.textContent?.trim();
    const company = document.querySelector('[data-automation-id="companyName"]')?.textContent?.trim() || '';
    const location = document.querySelector('[data-automation-id="locations"], .css-129m7dg')?.textContent?.trim();
    const description = document.querySelector('[data-automation-id="jobPostingDescription"], .css-1uv7dn3')?.innerText?.trim();

    return { title, company, location, description };
  },

  // MyWorkdayJobs
  'myworkdayjobs.com': () => {
    const title = document.querySelector('[data-automation-id="jobPostingHeader"], h2')?.textContent?.trim();
    const company = document.querySelector('[data-automation-id="companyName"]')?.textContent?.trim() || '';
    const location = document.querySelector('[data-automation-id="locations"]')?.textContent?.trim();
    const description = document.querySelector('[data-automation-id="jobPostingDescription"]')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Google Careers
  'careers.google.com': () => {
    const title = document.querySelector('h2.p1N2lc, .gc-card__title')?.textContent?.trim();
    const company = 'Google';
    const location = document.querySelector('.r0wTof, .gc-job-detail__location')?.textContent?.trim();
    const description = document.querySelector('.BDNOWe, .gc-job-detail__section--description')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Apple Jobs
  'jobs.apple.com': () => {
    const title = document.querySelector('#jd-job-title, h1')?.textContent?.trim();
    const company = 'Apple';
    const location = document.querySelector('#job-location-name')?.textContent?.trim();
    const description = document.querySelector('#jd-description, .job-description')?.innerText?.trim();

    return { title, company, location, description };
  },

  // Ashby
  'ashbyhq.com': () => {
    const title = document.querySelector('h1, .ashby-job-posting-heading')?.textContent?.trim();
    const company = document.querySelector('.ashby-job-posting-company-name')?.textContent?.trim() || '';
    const location = document.querySelector('.ashby-job-posting-location')?.textContent?.trim();
    const description = document.querySelector('.ashby-job-posting-description, .job-description')?.innerText?.trim();

    return { title, company, location, description };
  }
};

// Generic fallback extractor
function genericExtractor() {
  // Try common patterns
  const title = document.querySelector('h1, [class*="job-title"], [class*="jobTitle"], [data-testid*="title"]')?.textContent?.trim();
  const company = document.querySelector('[class*="company"], [class*="employer"], [data-testid*="company"]')?.textContent?.trim();
  const location = document.querySelector('[class*="location"], [data-testid*="location"]')?.textContent?.trim();

  // Try to get description from various common containers
  const descriptionSelectors = [
    '[class*="description"]',
    '[class*="job-details"]',
    '[id*="description"]',
    'article',
    'main'
  ];

  let description = '';
  for (const selector of descriptionSelectors) {
    const el = document.querySelector(selector);
    if (el && el.innerText.length > 200) {
      description = el.innerText.trim();
      break;
    }
  }

  return { title, company, location, description };
}

// Get the appropriate extractor for current site
function getExtractor() {
  const hostname = window.location.hostname.toLowerCase();

  for (const [site, extractor] of Object.entries(extractors)) {
    if (hostname.includes(site.replace('*.', ''))) {
      return extractor;
    }
  }

  return genericExtractor;
}

// Extract job data from current page
function extractJobData() {
  const extractor = getExtractor();
  const data = extractor();

  // Validate we got meaningful data
  if (data.description && data.description.length > 100) {
    return {
      success: true,
      data: {
        title: data.title || 'Unknown Position',
        company: data.company || 'Unknown Company',
        location: data.location || 'Unknown Location',
        description: data.description,
        url: window.location.href,
        extractedAt: new Date().toISOString()
      }
    };
  }

  return { success: false, data: null };
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractJob') {
    const result = extractJobData();
    sendResponse(result);
  }
  return true;
});

// Auto-detect job posting on page load
(function init() {
  // Wait for page to fully load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(checkAndNotify, 1000);
    });
  } else {
    setTimeout(checkAndNotify, 1000);
  }
})();

// Check if job posting and show subtle indicator
function checkAndNotify() {
  const result = extractJobData();
  if (result.success) {
    // Could add a subtle floating button here if desired
    console.log('[PASS ATS] Job posting detected:', result.data.title);
  }
}
