// Content scraper - Extracts job information from page
class JobScraper {
  constructor() {
    this.contentSelectors = CONFIG.EXTRACTION.CONTENT_SELECTORS;
    this.maxLength = CONFIG.EXTRACTION.MAX_CONTENT_LENGTH;
    this.contextChars = CONFIG.EXTRACTION.CONTEXT_CHARS;
  }

  /**
   * Extract job content from page
   * @returns {Object}
   */
  extractJobContent() {
    const content = this.findJobContent();
    const textContent = this.extractText(content);
    const metadata = this.extractBasicMetadata();

    return {
      textContent: textContent, // Send full content without truncation
      fullDescription: textContent, // Full job description for resume generation
      url: window.location.href,
      pageTitle: document.title,
      metadata
    };
  }

  /**
   * Find the main job content area
   * @returns {HTMLElement}
   */
  findJobContent() {
    // Try each selector in order
    for (const selector of this.contentSelectors) {
      try {
        const element = document.querySelector(selector);
        if (element && element.innerText.length > 200) {
          console.log('📄 Found content using selector:', selector);
          return element;
        }
      } catch (e) {
        continue;
      }
    }

    // Fallback: find largest text block
    console.log('⚠️ Using fallback: largest text block');
    return this.findLargestTextBlock();
  }

  /**
   * Find the element with the most text content
   * @returns {HTMLElement}
   */
  findLargestTextBlock() {
    let largestElement = document.body;
    let maxLength = 0;

    const candidates = document.querySelectorAll('div, section, article, main');
    for (const element of candidates) {
      const text = element.innerText || '';
      if (text.length > maxLength && text.length < 50000) {
        maxLength = text.length;
        largestElement = element;
      }
    }

    return largestElement;
  }

  /**
   * Extract clean text from element
   * @param {HTMLElement} element
   * @returns {string}
   */
  extractText(element) {
    let text = element.innerText || element.textContent || '';

    // Clean up whitespace
    text = text
      .replace(/\s+/g, ' ')           // Multiple spaces → single space
      .replace(/\n{3,}/g, '\n\n')     // Multiple newlines → double newline
      .trim();

    return text;
  }

  /**
   * Intelligently truncate text to fit within limits
   * Keep beginning and end context
   * @param {string} text
   * @returns {string}
   */
  truncateIntelligently(text) {
    if (text.length <= this.maxLength) {
      return text;
    }

    // Keep first portion and last portion
    const mainContent = text.substring(0, this.maxLength - this.contextChars);
    const endContext = text.substring(text.length - this.contextChars);

    return `${mainContent}\n\n...(content truncated)...\n\n${endContext}`;
  }

  /**
   * Extract basic metadata from page
   * @returns {Object}
   */
  extractBasicMetadata() {
    const metadata = {};

    // Try to extract job title
    metadata.title = this.extractJobTitle();

    // Try to extract company name
    metadata.company = this.extractCompanyName();

    // Try to extract location
    metadata.location = this.extractLocation();

    return metadata;
  }

  /**
   * Extract job title from page
   * @returns {string|null}
   */
  extractJobTitle() {
    // Check structured data
    const structuredData = this.getStructuredData();
    if (structuredData?.title) {
      return structuredData.title;
    }

    // Check meta tags
    const metaTitle = this.getMetaContent('og:title') ||
                      this.getMetaContent('twitter:title');
    if (metaTitle) {
      return metaTitle;
    }

    // Check h1
    const h1 = document.querySelector('h1');
    if (h1) {
      return h1.innerText.trim();
    }

    // Fallback to page title
    return document.title;
  }

  /**
   * Extract company name
   * @returns {string|null}
   */
  extractCompanyName() {
    // Check structured data
    const structuredData = this.getStructuredData();
    if (structuredData?.hiringOrganization?.name) {
      return structuredData.hiringOrganization.name;
    }

    // Check meta tags
    const metaSite = this.getMetaContent('og:site_name');
    if (metaSite) {
      return metaSite;
    }

    // Try to find company name in text
    const text = document.body.innerText;
    const companyMatch = text.match(/(?:Company|Employer|Organization):\s*([^\n]+)/i);
    if (companyMatch) {
      return companyMatch[1].trim();
    }

    return null;
  }

  /**
   * Extract location
   * @returns {string|null}
   */
  extractLocation() {
    // Check structured data
    const structuredData = this.getStructuredData();
    if (structuredData?.jobLocation?.address?.addressLocality) {
      return structuredData.jobLocation.address.addressLocality;
    }

    // Try to find location in text
    const text = document.body.innerText;
    const locationMatch = text.match(/(?:Location|City|Office):\s*([^\n]+)/i);
    if (locationMatch) {
      return locationMatch[1].trim();
    }

    return null;
  }

  /**
   * Get structured data (JSON-LD) from page
   * @returns {Object|null}
   */
  getStructuredData() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
      try {
        const data = JSON.parse(script.textContent);
        if (data['@type'] === 'JobPosting') {
          return data;
        }
      } catch (e) {
        continue;
      }
    }
    return null;
  }

  /**
   * Get meta tag content
   * @param {string} name
   * @returns {string|null}
   */
  getMetaContent(name) {
    const meta = document.querySelector(`meta[property="${name}"], meta[name="${name}"]`);
    return meta?.getAttribute('content');
  }
}

// Export for use by other scripts
console.log('📝 Quick Resume AI - Scraper script loaded');
window.jobScraper = new JobScraper();
console.log('✅ Job scraper initialized');

// Listen for auto-scrape-and-generate command from keyboard shortcut
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'auto-scrape-and-generate') {
    // Automatically scrape job posting
    const jobData = window.jobScraper.extractJobContent();

    if (jobData && jobData.fullDescription && jobData.fullDescription.length > 100) {
      // Show notification that generation started
      showNotification('🚀 Generating resume...', 'info');

      // Send to background for processing (optional, or handle directly)
      chrome.runtime.sendMessage({
        action: 'generate-resume',
        jobData: jobData
      });

      // Trigger API call directly from content script
      (async () => {
        try {
          const response = await apiClient.post('/api/process-job', {
            jobDescription: jobData.fullDescription,
            aiMode: 'gpt-5-mini',
            matchMode: 'standard'
          });

          if (response.jobId) {
            showNotification('✅ Resume generation started! Check the extension popup for progress.', 'success');
          }
        } catch (error) {
          console.error('Auto-generate failed:', error);
          showNotification('❌ Failed to generate resume. Please try again.', 'error');
        }
      })();

      sendResponse({ success: true });
    } else {
      showNotification('❌ Could not find job description on this page', 'error');
      sendResponse({ success: false, error: 'No job description found' });
    }

    return true; // Keep message channel open
  }
});

// Toast notification helper
function showNotification(message, type) {
  // Create toast notification on page
  const toast = document.createElement('div');
  toast.className = `quick-resume-toast ${type}`;
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 16px 24px;
    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    color: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 999999;
    font-family: system-ui;
    font-size: 14px;
    max-width: 320px;
    animation: slideIn 0.3s ease-out;
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'slideOut 0.3s ease-in';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
