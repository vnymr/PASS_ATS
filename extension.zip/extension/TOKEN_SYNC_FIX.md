# 🔧 Fix Token Sync Between Website and Extension

## The Problem
The website can't send the authentication token to the extension because:
1. The extension ID is unique for each installation
2. The website needs to know the extension ID to send messages
3. The extension ID isn't configured in the environment

## Quick Fix (Choose One)

### Option 1: Get Your Extension ID and Set It (Easiest)

1. **Get your extension ID**:
   - Go to `chrome://extensions`
   - Find "HappyResumes - AI Resume Builder"
   - Copy the ID (looks like: `abcdefghijklmnopqrstuvwxyz`)

2. **Set it in the website**:
   - Open https://happyresumes.com/dashboard
   - Open Chrome DevTools (F12)
   - Go to Console tab
   - Run this command (replace with YOUR extension ID):
   ```javascript
   localStorage.setItem('extensionId', 'YOUR_EXTENSION_ID_HERE');
   location.reload();
   ```

3. **Test it**:
   - After page reloads, you should see: "🔄 Syncing token to extension"
   - Click extension icon - should now show your usage!

### Option 2: Manual Token Copy (Works Always)

1. **Get your token from the website**:
   - Go to https://happyresumes.com/dashboard
   - Open DevTools Console (F12)
   - Run:
   ```javascript
   // This will copy your token
   (async () => {
    const response = await fetch('https://api.happyresumes.com/api/subscription', {
       headers: {
         'Authorization': `Bearer ${await window.Clerk.session.getToken()}`
       }
     });
     const token = await window.Clerk.session.getToken();
     console.log('Your token:', token);
     // Save it to extension
     chrome.runtime.sendMessage('YOUR_EXTENSION_ID', {
       type: 'CLERK_TOKEN_UPDATE',
       token: token
     });
   })();
   ```

### Option 3: Use Extension's Built-in Sync (Permanent Fix)

We need to modify the website to detect and store the extension ID automatically.

---

## Permanent Solution (For Developers)

### Add this to the website's Dashboard component:

```javascript
// Auto-detect extension
useEffect(() => {
  // Try to detect the extension
  const extensionIds = [
    'YOUR_PROD_EXTENSION_ID', // Production extension ID
    'YOUR_DEV_EXTENSION_ID',  // Development extension ID
  ];

  extensionIds.forEach(id => {
    try {
      chrome.runtime.sendMessage(id, { type: 'PING' }, response => {
        if (!chrome.runtime.lastError && response) {
          localStorage.setItem('extensionId', id);
          console.log('Extension detected:', id);
        }
      });
    } catch (e) {
      // Extension not found
    }
  });
}, []);
```

---

## Why This Happens

1. Chrome extensions have unique IDs
2. Websites can only send messages to extensions they know the ID of
3. The ID changes when you load an unpacked extension
4. The production extension will have a fixed ID

## For Testing Right Now

**Quickest fix**:
1. Get your extension ID from `chrome://extensions`
2. Open https://happyresumes.com/dashboard
3. Open Console and run:
```javascript
localStorage.setItem('extensionId', 'YOUR_ID_HERE');
location.reload();
```
4. Sign in again if needed
5. Extension should now work!

The extension will receive the token and authentication will work!
