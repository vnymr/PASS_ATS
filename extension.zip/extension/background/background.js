// Background service worker for PASS ATS extension

// Configuration
const APP_URL = 'https://passats.com'; // Update with your actual app URL

// Listen for installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('[PASS ATS] Extension installed');
    // Could open onboarding page here
  } else if (details.reason === 'update') {
    console.log('[PASS ATS] Extension updated');
  }
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openApp') {
    chrome.tabs.create({ url: APP_URL });
    sendResponse({ success: true });
  }

  if (request.action === 'openGenerate') {
    const url = request.jobData
      ? `${APP_URL}/generate?source=extension`
      : `${APP_URL}/generate`;
    chrome.tabs.create({ url });
    sendResponse({ success: true });
  }

  return true;
});

// Handle keyboard shortcuts (if configured)
chrome.commands?.onCommand?.addListener((command) => {
  if (command === 'extract-job') {
    // Get active tab and trigger extraction
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs[0]) {
        try {
          const response = await chrome.tabs.sendMessage(tabs[0].id, { action: 'extractJob' });
          if (response?.success) {
            await chrome.storage.local.set({
              pendingJobDescription: response.data
            });
            chrome.tabs.create({ url: `${APP_URL}/generate?source=extension` });
          }
        } catch (error) {
          console.log('[PASS ATS] Could not extract job from current page');
        }
      }
    });
  }
});
