/**
 * Quick test to verify browser launcher works
 */

import { launchStealthBrowser } from './lib/browser-launcher.js';
import logger from './lib/logger.js';

async function test() {
  logger.info('Testing browser launcher...');

  try {
    const browser = await launchStealthBrowser();
    logger.info('✅ Browser launched successfully');

    const page = await browser.newPage();
    await page.goto('https://www.google.com', { waitUntil: 'networkidle2' });
    logger.info('✅ Navigation successful');

    await browser.close();
    logger.info('✅ Browser closed successfully');

    console.log('\n✅ ALL TESTS PASSED - Browser launcher working correctly!\n');
    process.exit(0);
  } catch (error) {
    logger.error('❌ Browser launch test failed:', error);
    console.error('\n❌ TEST FAILED:', error.message, '\n');
    process.exit(1);
  }
}

test();
