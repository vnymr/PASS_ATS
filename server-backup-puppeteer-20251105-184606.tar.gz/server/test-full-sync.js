/**
 * Test Full Job Sync
 * Tests the complete system: free sources + ATS sources
 */

import jobSyncService from './lib/job-sync-service.js';
import logger from './lib/logger.js';

async function testFullSync() {
  logger.info('🧪 Testing FULL Job Sync System...\n');

  try {
    // Get initial stats
    const before = await jobSyncService.getJobCounts();
    logger.info('📊 Current jobs in database:');
    logger.info(`   - Total: ${before.total}`);
    logger.info(`   - Active: ${before.active}`);
    logger.info(`   - AI-applyable: ${before.aiApplyable}`);

    // Run full sync
    logger.info('\n🔄 Starting full job sync...');
    logger.info('   This will fetch from:');
    logger.info('   - FREE sources (HN, RSS, YC)');
    logger.info('   - Greenhouse companies');
    logger.info('   - Lever companies');
    logger.info('   - Remotive');
    logger.info('\n⏳ Please wait 1-2 minutes...\n');

    const result = await jobSyncService.syncJobs();

    logger.info('\n✅ Sync Complete!');
    logger.info(`   - New jobs saved: ${result.saved}`);
    logger.info(`   - Jobs updated: ${result.updated}`);
    logger.info(`   - Old jobs deleted: ${result.deleted}`);
    logger.info(`   - Duration: ${(result.duration / 1000).toFixed(1)}s`);

    // Get final stats
    const after = await jobSyncService.getJobCounts();
    logger.info('\n📊 Jobs in database now:');
    logger.info(`   - Total: ${after.total} (${after.total > before.total ? '+' : ''}${after.total - before.total})`);
    logger.info(`   - Active: ${after.active}`);
    logger.info(`   - AI-applyable: ${after.aiApplyable}`);

    logger.info('\n📈 By ATS Type:');
    Object.entries(after.byATS).forEach(([ats, count]) => {
      logger.info(`   - ${ats}: ${count}`);
    });

    logger.info('\n💡 System is working!');
    logger.info('   - Run "npm start" to enable daily auto-sync at midnight');
    logger.info('   - Company discovery runs daily at 2 AM to find new companies');
    logger.info('   - You now have real-time jobs from multiple sources!');

  } catch (error) {
    logger.error({ error: error.message, stack: error.stack }, 'Sync test failed');
  } finally {
    process.exit(0);
  }
}

testFullSync();
