// Quick test to verify Clerk token verification
import { createClerkClient } from '@clerk/clerk-sdk-node';

async function testClerkVerification() {
  const CLERK_SECRET = process.env.CLERK_SECRET_KEY || 'sk_test_mlhX3WfaKB9XJQ4yLO93a4nRvicJijhM956nWYt7nf';

  console.log('🔍 Testing Clerk configuration...');
  console.log('Secret Key:', CLERK_SECRET.substring(0, 20) + '...');

  const clerkClient = createClerkClient({ secretKey: CLERK_SECRET });

  // Try to get the instance info
  try {
    // This will help us verify the Clerk instance
    console.log('✅ Clerk client created successfully');
    console.log('🔑 Clerk instance should be: prepared-sailfish-49.clerk.accounts.dev');
    console.log('\nTo test token verification, we need a real token from the browser.');
    console.log('Please copy a token from the browser console (localStorage or network request)');
    console.log('\nOr check if the CLERK_SECRET_KEY matches the frontend VITE_CLERK_PUBLISHABLE_KEY instance');
  } catch (err) {
    console.error('❌ Clerk client creation failed:', err.message);
  }
}

testClerkVerification();
