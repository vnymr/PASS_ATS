/**
 * Edge Case Testing Suite
 * Tests boundary conditions, error handling, and unexpected inputs
 */

import logger from './lib/logger.js';
import { prisma } from './lib/prisma-client.js';
import AIResumeGenerator from './lib/ai-resume-generator.js';
import dotenv from 'dotenv';

dotenv.config();
dotenv.config({ path: '.env.local' });

const testResults = {
  passed: [],
  failed: [],
  warnings: []
};

function logTest(name, status, details = '') {
  const symbol = status === 'pass' ? '✅' : status === 'warn' ? '⚠️' : '❌';
  console.log(`${symbol} ${name}${details ? ': ' + details : ''}`);

  if (status === 'pass') testResults.passed.push(name);
  else if (status === 'warn') testResults.warnings.push(name);
  else testResults.failed.push(name);
}

/**
 * Test 1: Resume Generation with Missing Fields
 */
async function testMissingFields() {
  console.log('\n🧪 Testing Resume Generation with Missing Fields...');

  try {
    const generator = new AIResumeGenerator(process.env.OPENAI_API_KEY);

    // Test 1: Empty user data
    try {
      await generator.generateResume({}, 'Software Engineer position');
      logTest('Empty user data handling', 'fail', 'Should have thrown error');
    } catch (error) {
      if (error.message.includes('Insufficient user data') || error.message.includes('required')) {
        logTest('Empty user data handling', 'pass', 'Properly rejected');
      } else {
        logTest('Empty user data handling', 'warn', 'Unexpected error: ' + error.message);
      }
    }

    // Test 2: User with only name
    try {
      await generator.generateResume({
        personalInfo: { name: 'John Doe' }
      }, 'Software Engineer position');
      logTest('Minimal user data handling', 'fail', 'Should have thrown error');
    } catch (error) {
      if (error.message.includes('Insufficient user data') || error.message.includes('required')) {
        logTest('Minimal user data handling', 'pass', 'Properly rejected');
      } else {
        logTest('Minimal user data handling', 'warn', 'Unexpected error: ' + error.message);
      }
    }

    return true;
  } catch (error) {
    logTest('Missing Fields Test', 'fail', error.message);
    return false;
  }
}

/**
 * Test 2: Auto-Apply with Invalid Job
 */
async function testInvalidAutoApply() {
  console.log('\n🧪 Testing Auto-Apply Edge Cases...');

  try {
    // Test 1: Non-existent job
    const nonExistentJob = await prisma.aggregatedJob.findUnique({
      where: { id: 'non-existent-job-id-123' }
    });

    if (!nonExistentJob) {
      logTest('Non-existent job query', 'pass', 'Returns null correctly');
    }

    // Test 2: Inactive job
    const inactiveJob = await prisma.aggregatedJob.findFirst({
      where: { isActive: false }
    });

    if (inactiveJob) {
      logTest('Inactive job detection', 'pass', 'Can identify inactive jobs');
    } else {
      logTest('Inactive job detection', 'warn', 'No inactive jobs to test with');
    }

    // Test 3: Non-AI-applyable job
    const manualJob = await prisma.aggregatedJob.findFirst({
      where: { aiApplyable: false }
    });

    if (manualJob) {
      logTest('Manual job detection', 'pass', 'Can identify manual jobs');
    } else {
      logTest('Manual job detection', 'warn', 'No manual jobs to test with');
    }

    return true;
  } catch (error) {
    logTest('Invalid Auto-Apply Test', 'fail', error.message);
    return false;
  }
}

/**
 * Test 3: Large Input Handling
 */
async function testLargeInputs() {
  console.log('\n🧪 Testing Large Input Handling...');

  try {
    const generator = new AIResumeGenerator(process.env.OPENAI_API_KEY);

    // Create very long experience list
    const longExperience = Array(20).fill(null).map((_, i) => ({
      company: `Company ${i}`,
      position: 'Software Engineer',
      startDate: '2020-01-01',
      endDate: '2021-01-01',
      responsibilities: Array(10).fill('Built amazing software products')
    }));

    const userData = {
      personalInfo: {
        name: 'Test User',
        email: 'test@example.com'
      },
      experience: longExperience,
      education: [
        {
          institution: 'University',
          degree: 'BS Computer Science',
          graduationDate: '2019'
        }
      ],
      skills: Array(50).fill('JavaScript')
    };

    // This should handle gracefully (may truncate or warn)
    try {
      // Don't actually generate to save costs, just validate structure
      const processed = generator.preprocessUserData(userData);
      if (processed.experience.length === 20) {
        logTest('Large experience list handling', 'pass', 'Handles 20 jobs');
      }
    } catch (error) {
      logTest('Large experience list handling', 'warn', error.message);
    }

    return true;
  } catch (error) {
    logTest('Large Input Test', 'fail', error.message);
    return false;
  }
}

/**
 * Test 4: Special Characters and Unicode
 */
async function testSpecialCharacters() {
  console.log('\n🧪 Testing Special Characters...');

  try {
    const generator = new AIResumeGenerator(process.env.OPENAI_API_KEY);

    const userData = {
      personalInfo: {
        name: 'José García-López',
        email: 'josé@example.com',
        location: 'São Paulo, Brazil 🇧🇷'
      },
      experience: [
        {
          company: 'Empresa Española & Ñoño Inc.',
          position: 'Développeur Senior',
          startDate: '2020-01-01',
          endDate: '2023-01-01',
          responsibilities: ['Built apps with €1M+ revenue', 'Used C++, C#, and JavaScript']
        }
      ],
      education: [
        {
          institution: 'Université de Paris',
          degree: 'Master\'s Degree',
          graduationDate: '2019'
        }
      ],
      skills: ['JavaScript', 'Python', 'C++']
    };

    // Test preprocessing handles special chars
    const processed = generator.preprocessUserData(userData);

    if (processed.personalInfo.name === 'José García-López') {
      logTest('Unicode name handling', 'pass', 'Preserves special characters');
    }

    if (processed.experience[0].company.includes('Ñoño')) {
      logTest('Special characters in text', 'pass', 'Handles Spanish characters');
    }

    return true;
  } catch (error) {
    logTest('Special Characters Test', 'fail', error.message);
    return false;
  }
}

/**
 * Test 5: Concurrent Operations
 */
async function testConcurrentOperations() {
  console.log('\n🧪 Testing Concurrent Database Operations...');

  try {
    // Simulate multiple users querying jobs simultaneously
    const promises = Array(10).fill(null).map(() =>
      prisma.aggregatedJob.findMany({
        where: { isActive: true },
        take: 10
      })
    );

    const results = await Promise.all(promises);

    if (results.every(r => r.length > 0)) {
      logTest('Concurrent job queries', 'pass', '10 simultaneous queries succeeded');
    } else {
      logTest('Concurrent job queries', 'warn', 'Some queries returned empty');
    }

    return true;
  } catch (error) {
    logTest('Concurrent Operations Test', 'fail', error.message);
    return false;
  }
}

/**
 * Test 6: Pagination Edge Cases
 */
async function testPaginationEdges() {
  console.log('\n🧪 Testing Pagination Edge Cases...');

  try {
    // Test offset beyond available data
    const totalJobs = await prisma.aggregatedJob.count({ where: { isActive: true } });
    const beyondOffset = await prisma.aggregatedJob.findMany({
      where: { isActive: true },
      skip: totalJobs + 1000,
      take: 10
    });

    if (beyondOffset.length === 0) {
      logTest('Offset beyond data', 'pass', 'Returns empty array correctly');
    }

    // Test limit of 0
    const zeroLimit = await prisma.aggregatedJob.findMany({
      where: { isActive: true },
      take: 0
    });

    if (zeroLimit.length === 0) {
      logTest('Zero limit query', 'pass', 'Handles limit=0');
    }

    // Test very large limit
    const largeLimit = await prisma.aggregatedJob.findMany({
      where: { isActive: true },
      take: 10000
    });

    logTest('Large limit query', 'pass', `Returned ${largeLimit.length} jobs`);

    return true;
  } catch (error) {
    logTest('Pagination Edge Cases', 'fail', error.message);
    return false;
  }
}

/**
 * Test 7: LaTeX Special Characters
 */
async function testLatexSpecialChars() {
  console.log('\n🧪 Testing LaTeX Special Character Escaping...');

  try {
    const generator = new AIResumeGenerator(process.env.OPENAI_API_KEY);

    // Test cleaning LaTeX with special chars
    const testLatex = `\\documentclass{article}
\\begin{document}
Email: john_doe@example.com
Skills: C++ & Python
Salary: $100K+
Company: Smith & Johnson Inc.
\\end{document}`;

    const cleaned = generator.cleanLatex(testLatex);

    if (cleaned.includes('\\documentclass')) {
      logTest('LaTeX structure preservation', 'pass', 'Maintains structure');
    }

    return true;
  } catch (error) {
    logTest('LaTeX Special Characters', 'fail', error.message);
    return false;
  }
}

/**
 * Test 8: Null and Undefined Handling
 */
async function testNullHandling() {
  console.log('\n🧪 Testing Null/Undefined Handling...');

  try {
    // Test job query with null filters
    const jobsWithNull = await prisma.aggregatedJob.findMany({
      where: {
        isActive: true,
        atsType: null
      },
      take: 5
    });

    logTest('Null filter handling', 'pass', `Found ${jobsWithNull.length} jobs`);

    // Test profile with null data
    const userWithNullProfile = await prisma.user.findFirst({
      where: {
        profile: null
      }
    });

    if (userWithNullProfile) {
      logTest('Null profile detection', 'pass', 'Can find users without profiles');
    } else {
      logTest('Null profile detection', 'warn', 'All users have profiles (good!)');
    }

    return true;
  } catch (error) {
    logTest('Null Handling Test', 'fail', error.message);
    return false;
  }
}

/**
 * Main Test Runner
 */
async function runAllTests() {
  console.log('🧪 Starting Edge Case Testing Suite...\n');
  console.log('='.repeat(60));

  const tests = [
    { name: 'Missing Fields', fn: testMissingFields },
    { name: 'Invalid Auto-Apply', fn: testInvalidAutoApply },
    { name: 'Large Inputs', fn: testLargeInputs },
    { name: 'Special Characters', fn: testSpecialCharacters },
    { name: 'Concurrent Operations', fn: testConcurrentOperations },
    { name: 'Pagination Edges', fn: testPaginationEdges },
    { name: 'LaTeX Special Chars', fn: testLatexSpecialChars },
    { name: 'Null Handling', fn: testNullHandling }
  ];

  for (const test of tests) {
    try {
      await test.fn();
    } catch (error) {
      logTest(test.name, 'fail', `Unexpected error: ${error.message}`);
    }
  }

  // Print summary
  console.log('\n' + '='.repeat(60));
  console.log('\n📊 EDGE CASE TEST SUMMARY\n');
  console.log(`✅ Passed: ${testResults.passed.length}`);
  console.log(`❌ Failed: ${testResults.failed.length}`);
  console.log(`⚠️  Warnings: ${testResults.warnings.length}`);

  if (testResults.failed.length > 0) {
    console.log('\n❌ FAILED TESTS:');
    testResults.failed.forEach(test => console.log(`   - ${test}`));
  }

  if (testResults.warnings.length > 0) {
    console.log('\n⚠️  WARNINGS:');
    testResults.warnings.forEach(test => console.log(`   - ${test}`));
  }

  console.log('\n' + '='.repeat(60));

  if (testResults.failed.length === 0) {
    console.log('\n✅ ALL EDGE CASE TESTS PASSED!\n');
    process.exit(0);
  } else {
    console.log('\n❌ SOME EDGE CASE TESTS FAILED!\n');
    process.exit(1);
  }
}

// Run tests
runAllTests().catch(error => {
  console.error('Fatal test error:', error);
  process.exit(1);
});
