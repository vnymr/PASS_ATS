/**
 * Debug script to test auto-apply endpoint
 */
import { prisma } from './lib/prisma-client.js';
import logger from './lib/logger.js';

async function debugAutoApply() {
  try {
    console.log('\n🔍 Debugging Auto-Apply System\n');
    console.log('=' .repeat(60));

    // 1. Check if we have any jobs
    const totalJobs = await prisma.aggregatedJob.count();
    console.log(`\n✓ Total jobs in database: ${totalJobs}`);

    // 2. Check if we have any AI-applyable jobs
    const aiApplyableJobs = await prisma.aggregatedJob.count({
      where: { aiApplyable: true, isActive: true }
    });
    console.log(`✓ AI-applyable and active jobs: ${aiApplyableJobs}`);

    // 3. Show sample jobs
    if (totalJobs > 0) {
      console.log('\n📋 Sample jobs:');
      const sampleJobs = await prisma.aggregatedJob.findMany({
        take: 5,
        select: {
          id: true,
          title: true,
          company: true,
          aiApplyable: true,
          isActive: true,
          atsType: true,
          atsComplexity: true
        },
        orderBy: { postedDate: 'desc' }
      });

      sampleJobs.forEach((job, idx) => {
        console.log(`\n  ${idx + 1}. ${job.title} at ${job.company}`);
        console.log(`     ID: ${job.id}`);
        console.log(`     AI Applyable: ${job.aiApplyable ? '✓ Yes' : '✗ No'}`);
        console.log(`     Active: ${job.isActive ? '✓ Yes' : '✗ No'}`);
        console.log(`     ATS: ${job.atsType} (${job.atsComplexity})`);
      });
    }

    // 4. Check users
    const totalUsers = await prisma.user.count();
    console.log(`\n\n✓ Total users: ${totalUsers}`);

    if (totalUsers > 0) {
      const usersWithProfiles = await prisma.user.count({
        where: {
          profile: {
            isNot: null
          }
        }
      });
      console.log(`✓ Users with profiles: ${usersWithProfiles}`);

      // Check a sample user
      const sampleUser = await prisma.user.findFirst({
        include: { profile: true }
      });

      if (sampleUser) {
        console.log(`\n📋 Sample user:`);
        console.log(`   ID: ${sampleUser.id}`);
        console.log(`   Email: ${sampleUser.email}`);
        console.log(`   Has Profile: ${sampleUser.profile ? '✓ Yes' : '✗ No'}`);

        if (sampleUser.profile) {
          const hasApplicationData = sampleUser.profile.data?.applicationData;
          console.log(`   Has Application Data: ${hasApplicationData ? '✓ Yes' : '✗ No'}`);

          if (hasApplicationData) {
            const data = sampleUser.profile.data.applicationData;
            console.log(`   Personal Info: ${data.personalInfo ? '✓ Yes' : '✗ No'}`);
            if (data.personalInfo) {
              console.log(`     - Full Name: ${data.personalInfo.fullName || 'Not set'}`);
              console.log(`     - Email: ${data.personalInfo.email || 'Not set'}`);
              console.log(`     - Phone: ${data.personalInfo.phone || 'Not set'}`);
            }
          } else {
            console.log('\n   ⚠️  APPLICATION DATA MISSING!');
            console.log('   User needs to complete profile setup.');
            console.log('   Profile structure:', JSON.stringify(sampleUser.profile.data, null, 2));
          }
        }
      }
    }

    // 5. Check existing applications
    const totalApplications = await prisma.autoApplication.count();
    console.log(`\n\n✓ Total auto-applications: ${totalApplications}`);

    if (totalApplications > 0) {
      const recentApps = await prisma.autoApplication.findMany({
        take: 5,
        include: {
          job: {
            select: { title: true, company: true }
          },
          user: {
            select: { email: true }
          }
        },
        orderBy: { createdAt: 'desc' }
      });

      console.log('\n📋 Recent applications:');
      recentApps.forEach((app, idx) => {
        console.log(`\n  ${idx + 1}. ${app.job.title} at ${app.job.company}`);
        console.log(`     User: ${app.user.email}`);
        console.log(`     Status: ${app.status}`);
        console.log(`     Method: ${app.method}`);
        if (app.error) {
          console.log(`     Error: ${app.error}`);
        }
      });
    }

    console.log('\n' + '='.repeat(60));
    console.log('✅ Debug complete!\n');

  } catch (error) {
    console.error('❌ Debug failed:', error);
  } finally {
    await prisma.$disconnect();
  }
}

debugAutoApply();
