/**
 * Test parallel tool execution
 * Verifies that multiple consecutive tool actions are executed concurrently
 */

import { plan } from './lib/agents/persona.js';

async function testParallelExecution() {
  console.log('🧪 Testing Parallel Tool Execution\n');

  // Scenario 1: Multiple consecutive tool actions
  console.log('=== Scenario 1: Multiple Search Requests ===\n');

  const result1 = await plan({
    message: 'find software engineer jobs and product manager jobs and data scientist jobs',
    conversation: [],
    profileContext: 'User prefers remote jobs in tech.',
    userId: 1
  });

  console.log('Plan:', result1.plan);
  console.log('\nActions:');

  let consecutiveTools = 0;
  let maxConsecutiveTools = 0;
  let currentConsecutive = 0;

  result1.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content ? action.content.substring(0, 60) + '...' : action.name}`);

    if (action.type === 'tool') {
      currentConsecutive++;
      consecutiveTools++;
      maxConsecutiveTools = Math.max(maxConsecutiveTools, currentConsecutive);

      if (action.name === 'search_jobs') {
        console.log(`     Input: ${JSON.stringify(action.input)}`);
      }
    } else {
      currentConsecutive = 0;
    }
  });

  console.log(`\n📊 Tool Analysis:`);
  console.log(`   Total tools: ${consecutiveTools}`);
  console.log(`   Max consecutive tools: ${maxConsecutiveTools}`);

  if (maxConsecutiveTools >= 2) {
    console.log(`   ✅ DETECTED ${maxConsecutiveTools} CONSECUTIVE TOOLS - WILL EXECUTE IN PARALLEL!`);
  } else {
    console.log(`   ℹ️  LLM chose sequential execution (may use single broad search)`);
  }

  console.log('\n\n');

  // Scenario 2: Mixed actions (message, tools, message)
  console.log('=== Scenario 2: Mixed Action Types ===\n');

  const result2 = await plan({
    message: 'search for frontend jobs and backend jobs, then tell me which has more openings',
    conversation: [],
    profileContext: '',
    userId: 1
  });

  console.log('Plan:', result2.plan);
  console.log('\nActions:');

  let groups = [];
  let currentGroup = { type: null, count: 0 };

  result2.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content ? action.content.substring(0, 60) + '...' : action.name}`);

    if (action.type === currentGroup.type) {
      currentGroup.count++;
    } else {
      if (currentGroup.count > 0) {
        groups.push({ ...currentGroup });
      }
      currentGroup = { type: action.type, count: 1 };
    }
  });

  if (currentGroup.count > 0) {
    groups.push({ ...currentGroup });
  }

  console.log(`\n📊 Grouping Analysis:`);
  groups.forEach((group, idx) => {
    console.log(`   Group ${idx + 1}: ${group.count} ${group.type} action(s)`);
    if (group.type === 'tool' && group.count > 1) {
      console.log(`      ✅ Will execute ${group.count} tools in parallel`);
    }
  });

  console.log('\n\n');

  // Scenario 3: Sequential by design (tools that depend on each other)
  console.log('=== Scenario 3: Sequential Dependencies ===\n');

  const result3 = await plan({
    message: 'search for jobs, then create a goal to track 10 applications',
    conversation: [],
    profileContext: '',
    userId: 1
  });

  console.log('Plan:', result3.plan);
  console.log('\nActions:');

  let hasSearchThenGoal = false;
  for (let i = 0; i < result3.actions.length - 1; i++) {
    const current = result3.actions[i];
    const next = result3.actions[i + 1];

    console.log(`  ${i + 1}. ${current.type}: ${current.content ? current.content.substring(0, 60) + '...' : current.name}`);

    if (current.name === 'search_jobs' && next.name === 'create_goal') {
      hasSearchThenGoal = true;
    }
  }

  if (result3.actions.length > 0) {
    const last = result3.actions[result3.actions.length - 1];
    console.log(`  ${result3.actions.length}. ${last.type}: ${last.content ? last.content.substring(0, 60) + '...' : last.name}`);
  }

  console.log(`\n📊 Dependency Analysis:`);
  if (hasSearchThenGoal) {
    console.log(`   ✅ LLM correctly kept search_jobs and create_goal together`);
    console.log(`   ✅ No artificial separation - tools will execute in order`);
  } else {
    console.log(`   ℹ️  LLM chose a different approach`);
  }

  console.log('\n\n');

  // Scenario 4: Demonstrate actual grouping logic
  console.log('=== Scenario 4: Grouping Logic Demonstration ===\n');

  const mockActions = [
    { type: 'message', content: 'Searching...' },
    { type: 'tool', name: 'search_jobs', input: { role: 'Engineer' } },
    { type: 'tool', name: 'search_jobs', input: { role: 'Manager' } },
    { type: 'message', content: 'Results found' },
    { type: 'tool', name: 'track_applications' }
  ];

  // Simulate grouping (copy of the actual function logic)
  function testGrouping(actions) {
    const groups = [];
    let currentGroup = [];

    for (const action of actions) {
      if (action.type === 'tool') {
        currentGroup.push(action);
      } else {
        if (currentGroup.length > 0) {
          groups.push(currentGroup);
          currentGroup = [];
        }
        groups.push([action]);
      }
    }

    if (currentGroup.length > 0) {
      groups.push(currentGroup);
    }

    return groups;
  }

  const grouped = testGrouping(mockActions);

  console.log('Mock Actions:');
  mockActions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.name || action.content}`);
  });

  console.log('\nGrouped for Execution:');
  grouped.forEach((group, idx) => {
    if (group.length === 1) {
      const action = group[0];
      console.log(`  Group ${idx + 1}: [${action.type}] - Sequential`);
    } else {
      console.log(`  Group ${idx + 1}: [${group.map(a => a.type).join(', ')}] - ✅ PARALLEL (${group.length} tools)`);
    }
  });

  console.log('\n📊 Performance Benefit:');
  const toolGroups = grouped.filter(g => g.length > 1 && g.every(a => a.type === 'tool'));
  if (toolGroups.length > 0) {
    const parallelTools = toolGroups.reduce((sum, g) => sum + g.length, 0);
    console.log(`   ${parallelTools} tools will execute in parallel`);
    console.log(`   Estimated time saved: ~${(parallelTools - toolGroups.length) * 1000}ms`);
    console.log(`   (assuming 1000ms per tool, parallel groups execute simultaneously)`);
  }

  console.log('\n✅ Parallel execution test completed!\n');
}

// Run test
testParallelExecution().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
