import fetch from 'node-fetch';
import { config } from 'dotenv';

config();

const API_URL = process.env.API_BASE_URL || 'http://localhost:3000';
const TOKEN = process.env.TEST_TOKEN;

async function testAISearch() {
  if (!TOKEN) {
    console.error('❌ TEST_TOKEN environment variable is required');
    console.log('Set it with: export TEST_TOKEN="your-jwt-token"');
    process.exit(1);
  }

  console.log('🔍 Testing AI Search Endpoint...\n');

  try {
    const response = await fetch(`${API_URL}/api/ai-search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        query: 'software engineer',
        limit: 10,
        offset: 0
      })
    });

    console.log('📡 Response Status:', response.status, response.statusText);
    console.log('📡 Response Headers:', Object.fromEntries(response.headers.entries()));

    const data = await response.json();

    if (response.ok) {
      console.log('\n✅ SUCCESS!\n');
      console.log('Total Results:', data.total);
      console.log('Jobs Returned:', data.jobs?.length);
      console.log('Explanation:', data.explanation);
      console.log('Parsed Query:', JSON.stringify(data.parsedQuery, null, 2));

      if (data.jobs?.length > 0) {
        console.log('\nFirst Job:');
        console.log('  Title:', data.jobs[0].title);
        console.log('  Company:', data.jobs[0].company);
        console.log('  Location:', data.jobs[0].location);
      }
    } else {
      console.log('\n❌ ERROR RESPONSE:\n');
      console.log(JSON.stringify(data, null, 2));
    }

  } catch (error) {
    console.error('\n❌ Request Failed:\n');
    console.error(error.message);
    console.error(error.stack);
  }
}

testAISearch();
