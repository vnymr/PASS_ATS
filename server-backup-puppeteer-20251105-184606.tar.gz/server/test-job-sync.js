// Test script to trigger job sync manually
import 'dotenv/config';
import jobSyncService from './lib/job-sync-service.js';

console.log('🚀 Starting manual job sync test...\n');
console.log('Configuration:');
console.log(`  - Adzuna App ID: ${process.env.ADZUNA_APP_ID ? '✅' : '❌'}`);
console.log(`  - Adzuna API Key: ${process.env.ADZUNA_API_KEY ? '✅' : '❌'}`);
console.log(`  - Country: ${process.env.ADZUNA_COUNTRY || 'us'}`);
console.log('');

async function runTest() {
  try {
    // Sync with limited scope for testing
    const result = await jobSyncService.syncNow({
      // Adzuna only for testing
      useAdzuna: true,
      useRemotive: false,
      useJSearch: false,
      useReed: false,
      useJooble: false,
      useGreenhouse: false,
      useLever: false,

      // Fetch jobs from last 7 days (more results)
      keywords: 'software engineer',  // Filter for software engineering jobs
      location: '',  // All locations
      maxDaysOld: 7,
      limit: 100,  // Fetch 100 jobs (2 pages)
      pages: 2
    });

    console.log('\n✅ Job sync completed!');
    console.log('\nResults:');
    console.log(`  - New jobs saved: ${result.saved}`);
    console.log(`  - Updated jobs: ${result.updated}`);
    console.log(`  - Skipped: ${result.skipped}`);
    console.log(`  - Duration: ${(result.duration / 1000).toFixed(2)}s`);

    if (result.stats) {
      console.log('\nJob Statistics:');
      console.log(`  - Total fetched: ${result.stats.total}`);
      console.log(`  - AI-applyable: ${result.stats.aiApplyable} (${result.stats.aiApplyablePercent}%)`);
      console.log(`  - Manual only: ${result.stats.manualOnly} (${result.stats.manualOnlyPercent}%)`);
      console.log(`  - Unknown ATS: ${result.stats.unknown}`);
    }

    // Get job counts from database
    const counts = await jobSyncService.getJobCounts();
    console.log('\nDatabase Stats:');
    console.log(`  - Total jobs: ${counts.total}`);
    console.log(`  - Active jobs: ${counts.active}`);
    console.log(`  - AI-applyable: ${counts.aiApplyable}`);
    console.log(`  - Manual: ${counts.manual}`);

    console.log('\n✅ Test completed successfully!');
    process.exit(0);

  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
}

runTest();
