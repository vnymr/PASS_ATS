/**
 * Test auto-apply API endpoint
 */
import { prisma } from './lib/prisma-client.js';
import fetch from 'node-fetch';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'test-secret-key-123';
const API_URL = 'http://localhost:3000';

async function testAutoApply() {
  try {
    console.log('\n🧪 Testing Auto-Apply API\n');
    console.log('='.repeat(60));

    // 1. Get a test user with profile
    const user = await prisma.user.findFirst({
      where: {
        profile: {
          isNot: null
        }
      },
      include: { profile: true }
    });

    if (!user) {
      console.error('❌ No users with profiles found');
      process.exit(1);
    }

    console.log(`\n✓ Using test user: ${user.email} (ID: ${user.id})`);

    // 2. Get an AI-applyable job
    const job = await prisma.aggregatedJob.findFirst({
      where: {
        aiApplyable: true,
        isActive: true
      }
    });

    if (!job) {
      console.error('❌ No AI-applyable jobs found');
      process.exit(1);
    }

    console.log(`✓ Using test job: ${job.title} at ${job.company} (ID: ${job.id})`);

    // 3. Generate JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    console.log(`✓ Generated JWT token`);

    // 4. Call auto-apply API
    console.log('\n🚀 Calling POST /api/auto-apply...\n');

    const response = await fetch(`${API_URL}/api/auto-apply`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        jobId: job.id
      })
    });

    const data = await response.json();

    console.log('Response Status:', response.status);
    console.log('Response Body:', JSON.stringify(data, null, 2));

    if (response.ok) {
      console.log('\n✅ SUCCESS! Auto-apply endpoint working correctly');
      console.log(`\n   Application ID: ${data.applicationId}`);
      console.log(`   Status: ${data.status}`);
      console.log(`   Message: ${data.message}`);

      // Check if application was created in DB
      const application = await prisma.autoApplication.findUnique({
        where: { id: data.applicationId }
      });

      if (application) {
        console.log(`\n✓ Application record created in database`);
        console.log(`   Status: ${application.status}`);
        console.log(`   Method: ${application.method}`);
      }
    } else {
      console.log('\n❌ FAILED! Got error response');
      console.log(`   Error: ${data.error}`);
      console.log(`   Message: ${data.message || 'N/A'}`);
    }

    console.log('\n' + '='.repeat(60));

  } catch (error) {
    console.error('\n❌ Test failed with exception:', error.message);
    console.error(error.stack);
  } finally {
    await prisma.$disconnect();
  }
}

// Check if server is running first
fetch(API_URL)
  .then(() => {
    console.log('✓ Server is running at', API_URL);
    return testAutoApply();
  })
  .catch(() => {
    console.error('❌ Server is not running at', API_URL);
    console.error('   Please start the server first: npm start');
    process.exit(1);
  });
