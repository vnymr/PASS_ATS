/**
 * Test script for Aggressive Auto-Discovery System
 *
 * Run: node test-aggressive-discovery.js
 */

import aggressiveDiscovery from './lib/job-sources/aggressive-discovery.js';
import logger from './lib/logger.js';

async function testAggressiveDiscovery() {
  logger.info('🧪 Testing AGGRESSIVE Auto-Discovery System...\n');

  try {
    // Test full discovery
    logger.info('🚀 Running full company discovery...');
    const result = await aggressiveDiscovery.runFullDiscovery();

    logger.info(`\n✅ Discovery Complete!`);
    logger.info(`   - Total companies discovered: ${result.companies.length}`);
    logger.info(`   - Total jobs found: ${result.jobs.length}`);

    // Show breakdown by ATS type
    const atsCounts = {};
    result.companies.forEach(company => {
      atsCounts[company.atsType] = (atsCounts[company.atsType] || 0) + 1;
    });

    logger.info(`\n📊 Companies by ATS Type:`);
    Object.entries(atsCounts).forEach(([atsType, count]) => {
      logger.info(`   - ${atsType}: ${count}`);
    });

    // Show sample companies
    if (result.companies.length > 0) {
      logger.info(`\n📝 Sample discovered companies:`);
      result.companies.slice(0, 10).forEach((company, i) => {
        logger.info(`   ${i + 1}. ${company.name} (${company.atsType}) - ${company.slug}`);
      });
    }

    // Show sample jobs
    if (result.jobs.length > 0) {
      logger.info(`\n💼 Sample jobs:`);
      result.jobs.slice(0, 5).forEach((job, i) => {
        logger.info(`   ${i + 1}. ${job.title} at ${job.company}`);
      });
    }

    logger.info('\n💡 Summary:');
    logger.info(`   - You discovered ${result.companies.length} NEW companies automatically!`);
    logger.info(`   - These companies are now saved to your database`);
    logger.info(`   - Job sync will automatically fetch jobs from these companies`);
    logger.info(`   - This runs every week to keep discovering more!`);

  } catch (error) {
    logger.error({ error: error.message, stack: error.stack }, 'Test failed');
  }
}

// Run test
testAggressiveDiscovery();
