/**
 * Quick test - GitHub discovery only (no browsers needed)
 */

import aggressiveDiscovery from './lib/job-sources/aggressive-discovery.js';
import logger from './lib/logger.js';

async function quickTest() {
  logger.info('🧪 Quick Discovery Test (GitHub only)...\n');

  try {
    // Test GitHub discovery (fastest, no browser needed)
    const result = await aggressiveDiscovery.discoverViaGitHub();

    logger.info(`\n✅ GitHub Discovery Complete!`);
    logger.info(`   - Companies discovered: ${result.companies.length}`);
    logger.info(`   - Jobs found: ${result.jobs.length}`);

    // Show breakdown
    const atsCounts = {};
    result.companies.forEach(company => {
      atsCounts[company.atsType] = (atsCounts[company.atsType] || 0) + 1;
    });

    logger.info(`\n📊 Companies by ATS:`);
    Object.entries(atsCounts).forEach(([ats, count]) => {
      logger.info(`   - ${ats}: ${count}`);
    });

    // Show samples
    if (result.companies.length > 0) {
      logger.info(`\n📝 Sample companies:`);
      result.companies.slice(0, 10).forEach((c, i) => {
        logger.info(`   ${i + 1}. ${c.name} (${c.atsType})`);
      });
    }

    if (result.jobs.length > 0) {
      logger.info(`\n💼 Sample jobs:`);
      result.jobs.slice(0, 5).forEach((j, i) => {
        logger.info(`   ${i + 1}. ${j.title} at ${j.company}`);
      });
    }

    // Save to database
    if (result.companies.length > 0) {
      logger.info(`\n💾 Saving companies to database...`);
      const saved = await aggressiveDiscovery.saveDiscoveredCompanies(result.companies);
      logger.info(`✅ Saved ${saved.saved} companies!`);
    }

  } catch (error) {
    logger.error({ error: error.message, stack: error.stack }, 'Test failed');
  }
}

quickTest();
