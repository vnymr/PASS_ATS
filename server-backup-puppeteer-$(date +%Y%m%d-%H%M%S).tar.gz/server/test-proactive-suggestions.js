/**
 * Test proactive suggestions feature
 * Simulates a conversation with multiple job searches to trigger proactive routine suggestion
 */

import { plan } from './lib/agents/persona.js';

async function testProactiveSuggestions() {
  console.log('🧪 Testing Proactive Suggestions\n');

  // Scenario 1: User searches multiple times - should suggest routine
  console.log('=== Scenario 1: Repeated Searches (should suggest routine) ===\n');

  const conversation1 = [
    { role: 'user', content: 'find software engineer jobs' },
    { role: 'assistant', content: 'Searching for Software Engineer positions...\nFound 10 of 45 jobs (Software Engineer)' },
    { role: 'user', content: 'show me product manager roles' },
    { role: 'assistant', content: 'Searching for Product Manager positions...\nFound 10 of 32 jobs (Product Manager)' }
  ];

  const result1 = await plan({
    message: 'find data scientist jobs',
    conversation: conversation1,
    profileContext: 'User prefers remote jobs in tech.',
    userId: 1
  });

  console.log('Plan:', result1.plan);
  console.log('\nActions:');
  result1.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content || action.name}`);
    if (action.type === 'message' && action.content.includes('routine')) {
      console.log('     ✅ PROACTIVE SUGGESTION DETECTED!');
    }
  });

  console.log('\n\n');

  // Scenario 2: User mentions numeric target - should suggest goal
  console.log('=== Scenario 2: Numeric Target (should suggest goal) ===\n');

  const result2 = await plan({
    message: 'I need to apply to at least 15 jobs this week',
    conversation: [],
    profileContext: 'User prefers remote jobs in tech.',
    userId: 1
  });

  console.log('Plan:', result2.plan);
  console.log('\nActions:');
  result2.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content || action.name}`);
    if (action.type === 'message' && (action.content.includes('goal') || action.content.includes('track'))) {
      console.log('     ✅ PROACTIVE GOAL SUGGESTION DETECTED!');
    }
  });

  console.log('\n\n');

  // Scenario 3: User expresses frustration - should suggest automation
  console.log('=== Scenario 3: Frustration (should suggest automation) ===\n');

  const result3 = await plan({
    message: 'ugh I keep searching for the same roles every day',
    conversation: [],
    profileContext: 'User prefers remote jobs in tech.',
    userId: 1
  });

  console.log('Plan:', result3.plan);
  console.log('\nActions:');
  result3.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content || action.name}`);
    if (action.type === 'message' && (action.content.includes('routine') || action.content.includes('automate'))) {
      console.log('     ✅ PROACTIVE AUTOMATION SUGGESTION DETECTED!');
    }
  });

  console.log('\n\n');

  // Scenario 4: Simple greeting - should NOT be proactive
  console.log('=== Scenario 4: Simple Greeting (should NOT be proactive) ===\n');

  const result4 = await plan({
    message: 'hello',
    conversation: [],
    profileContext: '',
    userId: 1
  });

  console.log('Plan:', result4.plan);
  console.log('\nActions:');
  result4.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content || action.name}`);
  });

  const hasProactiveSuggestion = result4.actions.some(a =>
    a.type === 'message' && (a.content.includes('routine') || a.content.includes('goal'))
  );

  if (!hasProactiveSuggestion) {
    console.log('     ✅ CORRECTLY AVOIDED PROACTIVE SUGGESTION FOR GREETING');
  } else {
    console.log('     ⚠️  Should not suggest automation for simple greeting');
  }

  console.log('\n✅ Proactive suggestions test completed!\n');
}

// Run test
testProactiveSuggestions().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
