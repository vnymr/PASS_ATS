/**
 * Test autonomous AI workflow
 * Verifies that the AI proactively creates goals, searches jobs, and takes actions
 */

const BASE_URL = 'http://localhost:3000';

async function testAutonomousWorkflow() {
  console.log('🤖 Testing Autonomous AI Workflow');
  console.log('==================================\n');

  try {
    // Step 1: Register test user
    console.log('1️⃣ Creating test user...');
    const registerResponse = await fetch(`${BASE_URL}/api/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: `autonomous-test-${Date.now()}@example.com`,
        password: 'Testpass123'
      })
    });

    const registerData = await registerResponse.json();

    if (!registerData.token) {
      console.error('❌ Failed to register user:', registerData);
      process.exit(1);
    }

    const TOKEN = registerData.token;
    console.log('✅ User registered, got token:', TOKEN.substring(0, 20) + '...\n');

    // Step 2: Test autonomous goal creation
    console.log('2️⃣ Testing autonomous goal creation...');
    console.log('Message: "I want to find a product manager job"\n');

    const chatResponse1 = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        message: 'I want to find a product manager job',
        conversationId: 'test-autonomous-' + Date.now()
      })
    });

    // SSE response - read the stream
    const reader = chatResponse1.body.getReader();
    const decoder = new TextDecoder();
    let response = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      response += chunk;

      // Extract JSON from SSE events
      const lines = chunk.split('\n');
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.substring(6).trim();
          if (data && data !== '[DONE]') {
            try {
              const json = JSON.parse(data);
              if (json.content) {
                process.stdout.write(json.content);
              }
            } catch (e) {
              // Ignore parse errors for non-JSON lines
            }
          }
        }
      }
    }

    console.log('\n\n📝 AI Response Complete\n');

    // Step 3: Check if goals were created
    console.log('3️⃣ Checking if goals were created...');

    const goalsResponse = await fetch(`${BASE_URL}/api/goals`, {
      headers: { 'Authorization': `Bearer ${TOKEN}` }
    });

    const goalsData = await goalsResponse.json();

    console.log(`📊 Found ${goalsData.goals?.length || 0} goals\n`);

    if (goalsData.goals && goalsData.goals.length > 0) {
      console.log('✅ Goals created successfully!');
      goalsData.goals.forEach((goal, idx) => {
        console.log(`\n   Goal ${idx + 1}:`);
        console.log(`   - ID: ${goal.id}`);
        console.log(`   - Title: ${goal.title}`);
        console.log(`   - Type: ${goal.type}`);
        console.log(`   - Status: ${goal.status}`);
      });
    } else {
      console.log('⚠️ No goals found. AI may not have created goals automatically.');
    }

    // Step 4: Test proactive status check
    console.log('\n\n4️⃣ Testing proactive status check...');
    console.log('Message: "any updates?"\n');

    const chatResponse2 = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        message: 'any updates?',
        conversationId: 'test-autonomous-' + Date.now()
      })
    });

    const reader2 = chatResponse2.body.getReader();

    while (true) {
      const { done, value } = await reader2.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.substring(6).trim();
          if (data && data !== '[DONE]') {
            try {
              const json = JSON.parse(data);
              if (json.content) {
                process.stdout.write(json.content);
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }
    }

    console.log('\n\n✅ Autonomous workflow test complete!\n');
    console.log('Summary:');
    console.log('  ✓ AI responded to career goal expression');
    console.log('  ✓ Goals API is functional');
    console.log('  ✓ AI can provide status updates');
    console.log('\nCheck the responses above to verify autonomous behavior:');
    console.log('  - Did AI create goals automatically?');
    console.log('  - Did AI search for jobs proactively?');
    console.log('  - Did AI take initiative without explicit commands?');

  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

testAutonomousWorkflow();
