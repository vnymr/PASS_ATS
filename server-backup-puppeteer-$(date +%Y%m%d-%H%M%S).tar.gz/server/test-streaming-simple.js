/**
 * Simple test to verify end-to-end streaming works
 * Tests the actual /api/chat endpoint with timing measurements
 */

async function testEndToEndStreaming() {
  console.log('Testing end-to-end streaming to frontend...\n');

  const startTime = Date.now();
  let firstEventTime = null;
  let firstTextTime = null;
  let thinkingTime = null;

  try {
    const response = await fetch('http://localhost:3000/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Using valid JWT token for user ID 1
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MywiZW1haWwiOiJ0ZXN0LXVzZXJAZXhhbXBsZS5jb20iLCJpYXQiOjE3NjIwMDE0ODMsImV4cCI6MTc2MjA4Nzg4M30.2HoMe_3sbKBiRSGbhYN-5ejB_WcnNi4CTQie7-QWiMY'
      },
      body: JSON.stringify({
        message: 'Hello',
        conversationId: `test-${Date.now()}`
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    console.log('✅ Connection established');
    console.log('📡 Receiving SSE stream...\n');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop(); // Keep incomplete line in buffer

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const now = Date.now();
          const elapsed = now - startTime;

          if (!firstEventTime) {
            firstEventTime = now;
            console.log(`[${elapsed}ms] 🎯 First event received`);
          }

          try {
            const data = JSON.parse(line.slice(6));

            switch (data.type) {
              case 'connected':
                console.log(`[${elapsed}ms] Connected - Session ID: ${data.conversationId}`);
                break;

              case 'thinking':
                if (!thinkingTime) {
                  thinkingTime = now;
                  console.log(`[${elapsed}ms] 🤔 Thinking...`);
                }
                break;

              case 'text':
                if (!firstTextTime) {
                  firstTextTime = now;
                  console.log(`[${elapsed}ms] ✅ First text received!`);
                }
                console.log(`[${elapsed}ms] 📝 Text: "${data.content.substring(0, 60)}..."`);
                break;

              case 'tool_start':
                console.log(`[${elapsed}ms] 🔧 Tool started: ${data.tool}`);
                break;

              case 'tool_result':
                console.log(`[${elapsed}ms] ✓ Tool completed: ${data.tool}`);
                break;

              case 'done':
                console.log(`[${elapsed}ms] 🏁 Stream complete\n`);
                break;

              case 'error':
                console.log(`[${elapsed}ms] ❌ Error: ${data.error}`);
                break;
            }
          } catch (e) {
            // Skip unparseable lines
          }
        }
      }
    }

    const totalTime = Date.now() - startTime;

    console.log('=== PERFORMANCE SUMMARY ===');
    console.log(`Total time: ${totalTime}ms`);
    if (firstEventTime) {
      console.log(`Time to first event: ${firstEventTime - startTime}ms`);
    }
    if (thinkingTime) {
      console.log(`Time to thinking indicator: ${thinkingTime - startTime}ms`);
    }
    if (firstTextTime) {
      console.log(`Time to first text: ${firstTextTime - startTime}ms`);
      console.log(`\n🎉 User perceived latency: ${firstTextTime - startTime}ms`);

      if (firstTextTime - startTime < 1000) {
        console.log('✅ Excellent! Under 1 second');
      } else if (firstTextTime - startTime < 2000) {
        console.log('✅ Good! Under 2 seconds');
      } else {
        console.log('⚠️  Still slow, needs more optimization');
      }
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.cause) {
      console.error('Cause:', error.cause);
    }
  }
}

testEndToEndStreaming();
