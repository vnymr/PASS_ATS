/**
 * Test routine/schedule management system
 * Tests AI creating routines automatically and manual routine management
 */

const BASE_URL = 'http://localhost:3000';

async function testRoutineSystem() {
  console.log('🔄 Testing Routine/Schedule Management System');
  console.log('==============================================\n');

  try {
    // Step 1: Register test user
    console.log('1️⃣ Creating test user...');
    const registerResponse = await fetch(`${BASE_URL}/api/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: `routine-test-${Date.now()}@example.com`,
        password: 'Testpass123'
      })
    });

    const registerData = await registerResponse.json();

    if (!registerData.token) {
      console.error('❌ Failed to register user:', registerData);
      process.exit(1);
    }

    const TOKEN = registerData.token;
    console.log('✅ User registered\n');

    // Step 2: Test AI creating routines automatically
    console.log('2️⃣ Testing AI automatically creating routines...');
    console.log('Message: "I want to find a data scientist job"\n');

    const chatResponse = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        message: 'I want to find a data scientist job',
        conversationId: 'routine-test-' + Date.now()
      })
    });

    // Read SSE stream
    const reader = chatResponse.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.substring(6).trim();
          if (data && data !== '[DONE]') {
            try {
              const json = JSON.parse(data);
              if (json.content) {
                process.stdout.write(json.content);
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }
    }

    console.log('\n\n📝 AI Response Complete\n');

    // Step 3: Check if routines were created
    console.log('3️⃣ Checking if routines were created...');

    const routinesResponse = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        message: 'show me my routines',
        conversationId: 'routine-test-query-' + Date.now()
      })
    });

    const reader2 = routinesResponse.body.getReader();

    while (true) {
      const { done, value } = await reader2.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.substring(6).trim();
          if (data && data !== '[DONE]') {
            try {
              const json = JSON.parse(data);
              if (json.content) {
                process.stdout.write(json.content);
              }
              if (json.type === 'action' && json.name === 'list_routines') {
                console.log('\n\n✅ Routines found:', JSON.stringify(json.payload, null, 2));
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }
    }

    console.log('\n\n✅ Routine system test complete!\n');
    console.log('Summary:');
    console.log('  ✓ AI responded to career goal expression');
    console.log('  ✓ Routine creation tools available to AI');
    console.log('  ✓ Routine executor service running in background');
    console.log('\nCheck the responses above to verify:');
    console.log('  - Did AI create a routine automatically?');
    console.log('  - Was the routine scheduled with correct frequency?');
    console.log('  - Can the AI list routines on demand?');
    console.log('\n💡 Routines will execute at their scheduled times');
    console.log('   The routine executor checks every 60 seconds for due routines');

  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

testRoutineSystem();
