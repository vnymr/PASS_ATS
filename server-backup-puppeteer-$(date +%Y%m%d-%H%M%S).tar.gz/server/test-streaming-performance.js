/**
 * Test script to measure streaming performance improvement
 *
 * This tests the non-blocking memory search optimization
 */

import { plan } from './lib/agents/persona.js';

async function testPerformance() {
  console.log('Testing streaming performance with non-blocking memory search...\n');

  const testMessage = "Find me software engineer jobs in San Francisco";
  const userId = 1; // Test user ID

  console.log(`Test message: "${testMessage}"`);
  console.log(`User ID: ${userId}\n`);

  const startTime = Date.now();

  try {
    const result = await plan({
      message: testMessage,
      userId,
      conversation: [],
      profile: { location: 'San Francisco', role: 'Software Engineer' },
      profileContext: 'User prefers Software Engineer roles in San Francisco'
    });

    const totalTime = Date.now() - startTime;

    console.log('\n=== RESULTS ===');
    console.log(`Total response time: ${totalTime}ms`);
    console.log(`Plan: ${result.plan}`);
    console.log(`Actions: ${result.actions.length} actions planned`);

    if (totalTime < 1000) {
      console.log('\n✅ SUCCESS: Response time under 1 second!');
      console.log(`   Improvement: ~${Math.round((1400 - totalTime) / 1400 * 100)}% faster than baseline (1400ms)`);
    } else {
      console.log('\n⚠️  Response time still over 1 second');
      console.log('   Check if memory search is completing within timeout');
    }

  } catch (error) {
    console.error('Error during test:', error.message);
    console.error(error.stack);
  }
}

// Run test
testPerformance();
