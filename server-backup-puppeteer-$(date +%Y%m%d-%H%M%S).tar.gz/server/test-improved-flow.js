/**
 * Test Improved Auto-Apply Flow
 * Tests the new CAPTCHA handling and application flow
 */

import 'dotenv/config';
import ImprovedAutoApply from './lib/improved-auto-apply.js';
import logger from './lib/logger.js';

// Test user profile
const TEST_USER = {
  id: 'test-user-001',
  email: 'test@example.com',
  profile: {
    data: {
      applicationData: {
        personalInfo: {
          fullName: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1 (555) 123-4567',
          location: 'San Francisco, CA',
          linkedin: 'https://linkedin.com/in/johndoe',
          website: 'https://johndoe.dev'
        },
        experience: [
          {
            title: 'Senior Software Engineer',
            company: 'Tech Corp',
            duration: '2020 - Present',
            description: 'Led development of cloud infrastructure'
          }
        ],
        education: [
          {
            degree: 'BS Computer Science',
            school: 'Stanford University',
            year: '2018'
          }
        ],
        skills: ['JavaScript', 'Python', 'React', 'Node.js', 'AWS']
      }
    }
  }
};

// Test job data
const TEST_JOB = {
  title: 'Software Engineer',
  company: 'Test Company',
  location: 'Remote',
  description: 'We are looking for a talented software engineer...'
};

async function testImprovedFlow(jobUrl) {
  console.log('🚀 Testing Improved Auto-Apply Flow');
  console.log('='.repeat(60));
  console.log(`📍 Job URL: ${jobUrl}`);
  console.log('='.repeat(60));

  const improvedApply = new ImprovedAutoApply();
  const startTime = Date.now();

  try {
    console.log('\n⏰ Starting application process...\n');

    const result = await improvedApply.applyToJob(
      jobUrl,
      TEST_USER,
      TEST_JOB,
      null // No resume path for testing
    );

    const duration = Date.now() - startTime;

    // Display results
    console.log('\n' + '='.repeat(60));
    console.log('📊 RESULTS');
    console.log('='.repeat(60));
    console.log(`✅ Success: ${result.success}`);
    console.log(`⏱️  Duration: ${(duration / 1000).toFixed(2)} seconds`);
    console.log(`🔐 CAPTCHA Detected: ${result.captchaDetected ? 'Yes' : 'No'}`);

    if (result.captchaDetected) {
      console.log(`   Type: ${result.captchaType || 'Unknown'}`);
      console.log(`   Solved: ${result.captchaSolved ? 'Yes ✅' : 'No ❌'}`);
    }

    console.log(`📋 Fields Extracted: ${result.fieldsExtracted}`);
    console.log(`✍️  Fields Filled: ${result.fieldsFilled}`);

    if (result.fieldsExtracted > 0) {
      const fillRate = ((result.fieldsFilled / result.fieldsExtracted) * 100).toFixed(1);
      console.log(`📈 Fill Rate: ${fillRate}%`);
    }

    console.log(`💰 Total Cost: $${result.cost.toFixed(4)}`);

    if (result.errors.length > 0) {
      console.log(`\n❌ Errors (${result.errors.length}):`);
      result.errors.forEach((err, i) => {
        console.log(`   ${i + 1}. ${err}`);
      });
    }

    if (result.warnings.length > 0) {
      console.log(`\n⚠️  Warnings (${result.warnings.length}):`);
      result.warnings.forEach((warn, i) => {
        console.log(`   ${i + 1}. ${warn}`);
      });
    }

    // Save screenshot if available
    if (result.screenshot) {
      const fs = await import('fs');
      const path = await import('path');

      const outputDir = './test-output';
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }

      const screenshotPath = path.join(outputDir, `improved-flow-${Date.now()}.png`);
      const base64Data = result.screenshot.replace(/^data:image\/png;base64,/, '');
      fs.writeFileSync(screenshotPath, base64Data, 'base64');

      console.log(`\n📸 Screenshot saved: ${screenshotPath}`);
    }

    // Final verdict
    console.log('\n' + '='.repeat(60));
    if (result.success) {
      console.log('✅ TEST PASSED - Application completed successfully!');
    } else if (result.captchaDetected && !result.captchaSolved) {
      console.log('⚠️  TEST PARTIAL - CAPTCHA detected but not solved');
      console.log('   Check 2Captcha configuration and balance');
    } else {
      console.log('❌ TEST FAILED - Check errors above');
    }
    console.log('='.repeat(60));

    return result;

  } catch (error) {
    console.error('\n❌ Test failed with error:', error.message);
    console.error('Stack:', error.stack);

    const duration = Date.now() - startTime;
    console.log(`\n⏱️  Failed after ${(duration / 1000).toFixed(2)} seconds`);

    throw error;
  }
}

// Command line usage
const args = process.argv.slice(2);

if (args.length === 0) {
  console.log('📝 Improved Auto-Apply Flow Tester\n');
  console.log('Usage:');
  console.log('  node test-improved-flow.js <job-url>\n');
  console.log('Examples:');
  console.log('  node test-improved-flow.js "https://boards.greenhouse.io/company/jobs/123"');
  console.log('  node test-improved-flow.js "https://jobs.lever.co/company/123"');
  console.log('\nTest URLs:');
  console.log('  Greenhouse: https://job-boards.greenhouse.io/tenstorrent/jobs/4738082007');
  console.log('  Lever: https://jobs.lever.co/twilio');
  process.exit(1);
}

const jobUrl = args[0];
console.log('\n🔧 Configuration:');
console.log(`   2Captcha: ${process.env.TWOCAPTCHA_API_KEY ? 'Configured ✅' : 'Not configured ❌'}`);
console.log(`   Headless: ${process.env.HEADLESS !== 'false' ? 'Yes' : 'No'}`);
console.log(`   Skip CAPTCHA: ${process.env.SKIP_CAPTCHA_FOR_TESTING === 'true' ? 'Yes' : 'No'}`);
console.log();

testImprovedFlow(jobUrl)
  .then(() => {
    console.log('\n✅ Test completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Test failed:', error.message);
    process.exit(1);
  });