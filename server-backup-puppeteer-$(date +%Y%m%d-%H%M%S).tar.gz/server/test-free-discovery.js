/**
 * Test script for FREE Auto-Discovery Job Sources
 *
 * Run: node test-free-discovery.js
 */

import freeAutoDiscovery from './lib/job-sources/free-auto-discovery.js';
import logger from './lib/logger.js';

async function testFreeDiscovery() {
  logger.info('🧪 Testing FREE Auto-Discovery Sources...\n');

  try {
    // Test 1: SimplifyJobs GitHub
    logger.info('1️⃣ Testing SimplifyJobs GitHub...');
    const simplifyJobs = await freeAutoDiscovery.fetchSimplifyJobs();
    logger.info(`✅ SimplifyJobs: ${simplifyJobs.length} jobs\n`);
    if (simplifyJobs.length > 0) {
      logger.info('Sample job:', JSON.stringify(simplifyJobs[0], null, 2));
    }

    // Test 2: Hacker News
    logger.info('\n2️⃣ Testing Hacker News Who\'s Hiring...');
    const hnJobs = await freeAutoDiscovery.fetchHackerNewsJobs();
    logger.info(`✅ Hacker News: ${hnJobs.length} jobs\n`);
    if (hnJobs.length > 0) {
      logger.info('Sample job:', JSON.stringify(hnJobs[0], null, 2));
    }

    // Test 3: RSS Feeds
    logger.info('\n3️⃣ Testing RSS Feeds...');
    const rssJobs = await freeAutoDiscovery.fetchRSSFeeds();
    logger.info(`✅ RSS Feeds: ${rssJobs.length} jobs\n`);
    if (rssJobs.length > 0) {
      logger.info('Sample job:', JSON.stringify(rssJobs[0], null, 2));
    }

    // Test 4: Y Combinator
    logger.info('\n4️⃣ Testing Y Combinator Work at a Startup...');
    const ycJobs = await freeAutoDiscovery.fetchYCJobs();
    logger.info(`✅ Y Combinator: ${ycJobs.length} jobs\n`);
    if (ycJobs.length > 0) {
      logger.info('Sample job:', JSON.stringify(ycJobs[0], null, 2));
    }

    // Test 5: Full Aggregation
    logger.info('\n5️⃣ Testing Full Aggregation...');
    const result = await freeAutoDiscovery.aggregateAll();
    logger.info(`✅ Total unique jobs: ${result.jobs.length}`);
    logger.info(`   - SimplifyJobs: ${result.stats.simplify}`);
    logger.info(`   - Hacker News: ${result.stats.hackernews}`);
    logger.info(`   - RSS Feeds: ${result.stats.rss}`);
    logger.info(`   - Y Combinator: ${result.stats.yc}`);

    logger.info('\n✅ All tests passed!');
    logger.info(`\n💡 You now have ${result.jobs.length} jobs from 100% FREE sources!`);
    logger.info(`💰 Total cost: $0/month`);
    logger.info(`🔄 Updates: Real-time to daily`);

    // Show ATS breakdown
    const atsCounts = {};
    result.jobs.forEach(job => {
      atsCounts[job.atsType] = (atsCounts[job.atsType] || 0) + 1;
    });
    logger.info('\n📊 ATS Breakdown:');
    Object.entries(atsCounts).forEach(([ats, count]) => {
      logger.info(`   - ${ats}: ${count}`);
    });

  } catch (error) {
    logger.error({ error: error.message, stack: error.stack }, 'Test failed');
  }
}

// Run test
testFreeDiscovery();
