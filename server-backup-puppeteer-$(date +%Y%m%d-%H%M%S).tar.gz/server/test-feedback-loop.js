/**
 * Test LLM-native tool result feedback loop
 * Tests how the LLM analyzes 0-result searches and decides what to do
 */

import { plan } from './lib/agents/persona.js';

async function testFeedbackLoop() {
  console.log('🧪 Testing LLM-Native Tool Result Feedback Loop\n');

  // Scenario 1: LLM analyzes 0 results and decides to broaden search
  console.log('=== Scenario 1: LLM Analyzes 0 Results ===\n');

  const analysisPrompt = `The search returned 0 results. Original parameters: {"role":"Quantum Computing Engineer","location":"San Francisco","postedSince":"2025-10-31T00:00:00.000Z"}. Should I try a broader search, or would the user prefer to know there are no matches right now?`;

  const result1 = await plan({
    message: analysisPrompt,
    conversation: [
      { role: 'user', content: 'find quantum computing engineer jobs in san francisco posted today' },
      { role: 'assistant', content: 'Searching for Quantum Computing Engineer positions in San Francisco...\nFound 0 of 0 jobs' }
    ],
    profileContext: 'User prefers remote jobs in tech.',
    userId: 1
  });

  console.log('Plan:', result1.plan);
  console.log('\nActions:');
  result1.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content ? action.content.substring(0, 100) + '...' : action.name}`);

    if (action.type === 'tool' && action.name === 'search_jobs') {
      console.log('     Input:', JSON.stringify(action.input, null, 2));

      const usesQuery = !!action.input.query;
      const hasLocationFilter = !!action.input.location;
      const hasDateFilter = !!action.input.postedSince;

      if (usesQuery) {
        console.log('     ✅ LLM CHOSE TO USE QUERY INSTEAD OF EXACT ROLE');
      }

      if (!hasLocationFilter) {
        console.log('     ✅ LLM REMOVED LOCATION RESTRICTION');
      } else {
        console.log('     ℹ️  LLM kept location:', action.input.location);
      }

      if (hasDateFilter) {
        const originalDate = new Date('2025-10-31T00:00:00.000Z');
        const newDate = new Date(action.input.postedSince);
        if (newDate < originalDate) {
          const daysDiff = Math.round((originalDate - newDate) / (1000 * 60 * 60 * 24));
          console.log(`     ✅ LLM EXPANDED DATE RANGE BY ${daysDiff} DAYS`);
        }
      }
    }
  });

  console.log('\n\n');

  // Scenario 2: LLM handles AI-applyable filter with 0 results
  console.log('=== Scenario 2: LLM Handles Filter with 0 Results ===\n');

  const analysisPrompt2 = `The search returned 0 results. Original parameters: {"filter":"ai_applyable","role":"Data Scientist"}. Should I try a broader search, or would the user prefer to know there are no matches right now?`;

  const result2 = await plan({
    message: analysisPrompt2,
    conversation: [
      { role: 'user', content: 'find ai-applyable data scientist jobs' },
      { role: 'assistant', content: 'Searching for AI-applyable Data Scientist positions...\nFound 0 of 0 jobs' }
    ],
    profileContext: '',
    userId: 1
  });

  console.log('Plan:', result2.plan);
  console.log('\nActions:');
  result2.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content ? action.content.substring(0, 100) + '...' : action.name}`);

    if (action.type === 'tool' && action.name === 'search_jobs') {
      console.log('     Input:', JSON.stringify(action.input, null, 2));

      if (!action.input.filter || action.input.filter === 'all') {
        console.log('     ✅ LLM REMOVED AI-APPLYABLE FILTER');
      }
    }
  });

  console.log('\n\n');

  // Scenario 3: LLM decides NOT to broaden (user wants exact match)
  console.log('=== Scenario 3: LLM Respects User Intent ===\n');

  const analysisPrompt3 = `The search returned 0 results. Original parameters: {"company":"SpaceX","role":"Rocket Scientist"}. Should I try a broader search, or would the user prefer to know there are no matches right now?`;

  const result3 = await plan({
    message: analysisPrompt3,
    conversation: [
      { role: 'user', content: 'find rocket scientist jobs at spacex only - i only want to work there' },
      { role: 'assistant', content: 'Searching for Rocket Scientist positions at SpaceX...\nFound 0 of 0 jobs' }
    ],
    profileContext: '',
    userId: 1
  });

  console.log('Plan:', result3.plan);
  console.log('\nActions:');
  result3.actions.forEach((action, idx) => {
    console.log(`  ${idx + 1}. ${action.type}: ${action.content ? action.content.substring(0, 150) + '...' : action.name}`);

    if (action.type === 'message' && !result3.actions.some(a => a.type === 'tool')) {
      console.log('     ✅ LLM CORRECTLY CHOSE NOT TO BROADEN (respecting user constraint)');
    }
  });

  console.log('\n✅ LLM-native feedback loop test completed!\n');
}

// Run test
testFeedbackLoop().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
